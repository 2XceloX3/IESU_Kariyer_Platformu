import React, { useState } from 'react';
import { Search, Bell, MessageCircle, Briefcase, Bookmark, Heart, Send, Plus, Users, Compass, UserCircle2, MoreHorizontal, X, ShieldCheck, Crown, CheckCircle2, LayoutDashboard, FileText, Home } from 'lucide-react';

import { Star, UserCheck, ArrowRight } from 'lucide-react';
import JobsAndInternships from './JobsAndInternships';
import MessagingInterface from './MessagingInterface';
import PostComposer from './PostComposer';
import PostCard from './PostCard';

import { combineFeedItems } from '../utils/feedCombiner';
import CareerRadar from './CareerRadar';
import CareerNetwork from './CareerNetwork';
import Logo from './Logo';
import TopProfileMenu from './TopProfileMenu';

export default function AcademicStaffFeed({ setView, setSelectedUserId, notifications = [], setNotifications, posts, setPosts, surveys, userRole, news, events, students, alumni, companies, currentUser, featuredOpportunities, mentorships, messages, setMessages, applications, setApplications, jobs, academicStaff, announcements, academicRole }) {
  const [activeTab, setActiveTab] = useState('feed'); // feed, jobs, network
  const [searchQuery, setSearchQuery] = useState('');

  // Removed mock stories and defaultPosts

  return (
    <div className="min-h-screen bg-transparent font-sans">
      {/* Hyper-Modern Navbar (Glassmorphism) */}
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-xl border-b border-gray-100 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 cursor-pointer shrink-0" onClick={() => setView('landing')}>
              <Logo className="h-10 w-auto text-slate-700 hover:scale-105 transition-transform" />
            </div>
            <div className="hidden md:flex relative group">
              <Search className="absolute left-3 top-2.5 text-gray-400 group-focus-within:text-iesu-red transition-colors" size={18} />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Öğrenci, etkinlik, mentorluk veya duyuru ara..." 
                className="bg-gray-100/80 pl-10 pr-4 py-2 rounded-2xl text-[14px] w-72 focus:outline-none focus:bg-white focus:ring-2 focus:ring-iesu-coral/20 transition-all" 
              />
            </div>
          </div>
          
          {/* RIGHT: Navigation Icons & Profile */}
          <div className="flex items-center gap-1 sm:gap-3 shrink-0">
            <NavIcon icon={<Home />} label="Akış" active={activeTab === 'feed'} onClick={() => setActiveTab('feed')} />
            <NavIcon icon={<Compass />} label="Kariyer Ağı" active={activeTab === 'career_network'} onClick={() => setActiveTab('career_network')} />
            <NavIcon icon={<Briefcase />} label="İş ve Staj" active={activeTab === 'jobs'} onClick={() => setActiveTab('jobs')} />
            <NavIcon 
              icon={<MessageCircle />} 
              label="Mesajlar" 
              badge={messages?.filter(m => m.receiverId === currentUser?.id && !m.read).length || 0} 
              active={activeTab === 'messaging'} 
              onClick={() => setActiveTab('messaging')} 
            />
            <NavIcon 
              icon={<Bell />} 
              label="Bildirimler" 
              badge={(notifications || []).filter(n => n.userId === currentUser?.id && !n.read).length || 0} 
              active={activeTab === 'notifications'} 
              onClick={() => setView('notifications')} 
            />
            
            <TopProfileMenu currentUser={currentUser || { name: 'Akademik', avatar: 'https://ui-avatars.com/api/?name=Akademik&background=475569&color=fff' }} userRole={userRole || 'academic'} setView={setView} setSelectedUserId={setSelectedUserId} academicRole={academicRole} currentView="academic" />
          </div>
        </div>
      </nav>

      {/* Main Container - Padded for Navbar */}
      <div className="pt-24 max-w-6xl mx-auto px-4 flex justify-center gap-6 pb-20">
        
        {/* LEFT PANEL: Profile (Fast Access) */}
        <div className="hidden lg:block w-[300px] shrink-0">
          <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)] sticky top-24">
            {userRole === 'admin' ? (
              <div className="p-6 text-center">
                <div className="relative inline-block mb-2">
                  <div className="w-20 h-20 bg-gradient-to-tr from-orange-100 to-orange-50 rounded-2xl flex items-center justify-center border border-orange-200 shadow-sm mx-auto">
                    <ShieldCheck size={32} className="text-orange-500" />
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-orange-500 text-white p-1.5 rounded-xl shadow-md border-2 border-white">
                    <Crown size={14} />
                  </div>
                </div>
                <h2 className="text-[16px] font-black text-gray-900 mt-4 leading-tight">Kariyer Geliştirme Ofisi</h2>
                <p className="text-[12px] font-bold text-orange-600 mt-1 uppercase tracking-wider">SÜPER YÖNETİCİ</p>
                
                <div className="mt-6 flex flex-col gap-2 text-left bg-gray-50 p-3 rounded-2xl">
                  <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Sistem Yetkileri</p>
                  <div className="flex items-center gap-2 text-[12px] font-semibold text-gray-700">
                    <CheckCircle2 size={14} className="text-emerald-500" /> Tüm panellere tam erişim
                  </div>
                  <div className="flex items-center gap-2 text-[12px] font-semibold text-gray-700">
                    <CheckCircle2 size={14} className="text-emerald-500" /> İçerik yönetimi
                  </div>
                  <div className="flex items-center gap-2 text-[12px] font-semibold text-gray-700">
                    <CheckCircle2 size={14} className="text-emerald-500" /> Kullanıcı onayları
                  </div>
                </div>

                <button onClick={() => setView('admin')} className="mt-6 w-full flex items-center justify-center gap-2 bg-gray-900 hover:bg-black text-white text-[13px] font-bold py-3 rounded-xl transition-all shadow-md">
                  <LayoutDashboard size={16} /> Yönetim Panelini Aç
                </button>
              </div>
            ) : (
              <>
                <div className="h-24 bg-gradient-to-r from-slate-700 to-slate-900 relative">
                  <div className="absolute -bottom-10 left-1/2 -translate-x-1/2">
                    <div className="w-20 h-20 rounded-full border-4 border-white overflow-hidden bg-white">
                      <img src={currentUser?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser?.name || 'Akademik')}&background=475569&color=fff`} alt="User" className="w-full h-full object-cover" />
                    </div>
                  </div>
                </div>
                <div className="pt-14 pb-6 px-6 text-center">
                  <h2 className="text-[18px] font-black text-gray-900 leading-none mb-1 cursor-pointer hover:text-slate-700 transition">{currentUser?.name || 'Akademik Personel'}</h2>
                  <p className="text-[13px] font-medium text-gray-500 mb-4">
                    {currentUser?.department || 'Akademik Birim'}
                  </p>
                  
                  <div className="flex justify-center gap-6 border-y border-gray-50 py-4 mb-4">
                    <div className="text-center cursor-pointer group">
                      <p className="text-gray-400 text-[11px] font-bold uppercase tracking-wider mb-0.5">Öğrenciler</p>
                      <p className="text-[16px] font-black text-gray-900 group-hover:text-slate-700 transition">45</p>
                    </div>
                    <div className="w-px bg-gray-100"></div>
                    <div className="text-center cursor-pointer group">
                      <p className="text-gray-400 text-[11px] font-bold uppercase tracking-wider mb-0.5">Etkinlik</p>
                      <p className="text-[16px] font-black text-gray-900 group-hover:text-slate-700 transition">2</p>
                    </div>
                  </div>
                  <button className="w-full py-2.5 bg-slate-50 text-slate-700 hover:bg-slate-100 rounded-xl text-[13px] font-bold transition-colors">
                    Akademik Profili Düzenle
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* CENTER PANEL: Stories & Feed */}
        <div className="w-full max-w-[600px] shrink-0 space-y-6">
          
          {/* PROFESSIONAL HIGHLIGHTS */}
          <CareerRadar announcements={announcements} events={events} jobs={jobs} setView={setView} />

          {/* CREATE POST (Quick Action) */}
          <PostComposer currentUser={currentUser} posts={posts} setPosts={setPosts} />

          {/* FEED POSTS */}
          <div className="space-y-6">
            {(() => {
              const allItems = combineFeedItems(posts, events, news, announcements, jobs);
              const filtered = allItems.filter(post => post.content?.toLowerCase().includes(searchQuery.toLowerCase()) || post.author?.name?.toLowerCase().includes(searchQuery.toLowerCase()));
              
              if (filtered.length === 0) {
                return (
                  <div className="p-10 text-center bg-white rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-center justify-center min-h-[300px]">
                    <div className="w-16 h-16 bg-red-50 text-iesu-red rounded-2xl flex items-center justify-center mb-6 shadow-sm"><FileText size={32} /></div>
                    <h3 className="text-lg sm:text-xl font-black text-gray-900 mb-2">Henüz görüntülenecek yayın bulunmuyor.</h3>
                    <p className="text-sm text-gray-500 font-medium max-w-sm leading-relaxed">Duyuru, etkinlik, staj ve mentorluk içerikleri yayınlandığında burada görünecek.</p>
                  </div>
                );
              }
              
              return filtered.map(post => (
                <PostCard key={post.id} post={post} />
              ));
            })()}
          </div>

        </div>

        {/* RIGHT PANEL: Dynamic Data */}
        <div className="hidden xl:block w-[300px] shrink-0 space-y-6">
          
          {/* Profile Completion / Quick Action */}
          <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-[var(--border-soft)] p-6 shadow-[var(--shadow-soft)]">
            <h3 className="font-black text-gray-900 mb-2">Mentorluk Talepleri</h3>
            <p className="text-xs text-gray-500 font-medium mb-4">Danışmanı olduğunuz veya mentorluk talep eden öğrenciler.</p>
            <button className="w-full py-2 bg-slate-50 text-slate-700 hover:bg-slate-100 rounded-xl text-[13px] font-bold transition-colors">Talepleri İncele</button>
          </div>

          {/* Featured Opportunities */}
          {featuredOpportunities && (featuredOpportunities || []).filter(f => f.status === 'Yayında').length > 0 && (
            <div className="sticky top-24 bg-white/80 backdrop-blur-xl rounded-3xl border border-[var(--border-soft)] p-6 shadow-[var(--shadow-soft)]">
              <h3 className="font-black text-gray-900 mb-4 flex items-center gap-2">
                <Star size={18} className="text-yellow-500 fill-current" /> Öne Çıkanlar
              </h3>
              <div className="space-y-4">
                {(featuredOpportunities || []).filter(f => f.status === 'Yayında').slice(0,2).map(feat => (
                  <div key={feat.id} className="group cursor-pointer">
                    <div className="h-24 bg-gray-200 rounded-xl overflow-hidden mb-3 relative">
                      {feat.banner ? <img src={feat.banner} className="w-full h-full object-cover group-hover:scale-105 transition" /> : <div className="w-full h-full bg-gradient-to-r from-red-600 to-red-800"></div>}
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition"></div>
                      <div className="absolute bottom-2 left-2 right-2">
                        <p className="text-white text-[12px] font-black truncate">{feat.title}</p>
                        <p className="text-white/80 text-[10px] font-medium truncate">{feat.organization}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mentorships */}
          {mentorships && (mentorships || []).filter(m => m.status === 'Aktif').length > 0 && (
            <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-[var(--border-soft)] p-6 shadow-[var(--shadow-soft)]">
              <h3 className="font-black text-gray-900 mb-4 flex items-center gap-2">
                <UserCheck size={18} className="text-blue-500" /> Mentorluk Başvuruları
              </h3>
              <div className="space-y-3">
                {(mentorships || []).filter(m => m.status === 'Aktif').slice(0,3).map(mnt => (
                  <div key={mnt.id} className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 hover:border-blue-300 transition cursor-pointer group">
                    <p className="text-[12px] font-black text-gray-900 group-hover:text-blue-700 transition">{mnt.programTitle}</p>
                    <p className="text-[11px] text-gray-500">{mnt.mentorName} • {mnt.department}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'career_network' && (
            <CareerNetwork companies={companies} events={events} setView={setView} setSelectedUserId={setSelectedUserId} />
          )}

        </div>

        {/* Messaging Interface Overlay */}
        {activeTab === 'messaging' && (
          <div className="fixed inset-0 z-50 bg-gray-900/50 flex items-center justify-center p-4 sm:p-6 backdrop-blur-sm">
            <div className="bg-white rounded-3xl w-full max-w-5xl h-[85vh] overflow-hidden flex flex-col shadow-2xl animate-fade-in relative">
              <button 
                onClick={() => setActiveTab('feed')}
                className="absolute top-4 right-4 z-50 p-2 bg-white text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-full shadow-md transition border border-gray-100"
              >
                <X size={20} />
              </button>
              <MessagingInterface 
                messages={messages} 
                setMessages={setMessages} 
                currentUser={currentUser || { id: 'acd-1', name: 'Akademisyen', avatar: 'https://ui-avatars.com/api/?name=A&background=475569&color=fff' }} 
                userRole={userRole} 
                contacts={[...(students || []), ...(alumni || []), ...(companies || []), ...(academicStaff || [])]}
                setView={setView}
                setSelectedUserId={setSelectedUserId}
              />
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

// Helper component for Navbar Icons
const NavIcon = ({ icon, label, badge, active, onClick }) => (
  <button onClick={onClick} className={`flex flex-col items-center justify-center min-w-[56px] gap-1 p-1 sm:p-2 transition-all relative rounded-xl ${active ? 'text-iesu-red' : 'text-gray-400 hover:text-gray-900 hover:bg-gray-50'}`}>
    <div className={`flex items-center justify-center transition-transform ${active ? 'scale-110' : ''}`}>{icon}</div>
    <span className={`text-[9px] sm:text-[10px] whitespace-nowrap ${active ? 'font-black' : 'font-bold'}`}>{label}</span>
    {badge > 0 && <span className="absolute top-0 right-0 sm:right-2 w-4 h-4 bg-iesu-red text-white text-[9px] flex items-center justify-center rounded-full font-black ring-2 ring-white">{badge}</span>}
    {active && <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-1 bg-iesu-red rounded-full"></div>}
  </button>
);
