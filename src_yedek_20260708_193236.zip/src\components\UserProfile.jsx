import React, { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, Briefcase, GraduationCap, Mail, MessageSquare, ExternalLink, Calendar, Star, Building2, UserCircle2, Award, FileText, CheckCircle2, BookOpen, UserPlus, UserCheck, Users } from 'lucide-react';
import { Badge } from './admin/AdminCMSLayout';
import PostCard from './PostCard';

export default function UserProfile({ userId, setView, previousView, students, alumni, companies, academicStaff, currentUser, setDirectMessageUser, userRole, posts = [], setPosts }) {
  const [user, setUser] = useState(null);
  const [userType, setUserType] = useState(null);
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    if (currentUser && (userId === currentUser.id || userId === parseInt(currentUser.id))) {
      setUser(currentUser);
      setUserType(userRole === 'employer' ? 'company' : userRole === 'admin' ? 'admin' : userRole);
      return;
    }

    let found = (students || []).find(s => s.id === userId || s.id === parseInt(userId));
    if (found) { setUser(found); setUserType('student'); return; }

    found = (alumni || []).find(a => a.id === userId || a.id === parseInt(userId));
    if (found) { setUser(found); setUserType('alumni'); return; }

    found = (companies || []).find(c => c.id === userId || c.id === parseInt(userId));
    if (found) { setUser(found); setUserType('company'); return; }

    found = (academicStaff || []).find(a => a.id === userId || a.id === parseInt(userId));
    if (found) { setUser(found); setUserType('academic'); return; }
    
    setUser(null);
  }, [userId, students, alumni, companies, academicStaff]);

  if (!user) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-6">
          <UserCircle2 size={40} className="text-gray-400" />
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2">Kullanıcı Bulunamadı</h2>
        <p className="text-gray-500 mb-6">Aradığınız profil silinmiş veya mevcut olmayabilir.</p>
        <button onClick={() => setView(previousView || (userRole ? (userRole === 'admin' ? 'admin' : userRole) : 'landing'))} className="flex items-center gap-2 bg-iesu-red text-white px-6 py-2.5 rounded-xl font-bold hover:bg-red-700 transition">
          <ArrowLeft size={18} /> Geri Dön
        </button>
      </div>
    );
  }

  const handleMessage = () => {
    if (setDirectMessageUser) {
      setDirectMessageUser(user);
    }
    setView('messaging');
  };

  const renderStudentProfile = () => (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
      <div className="h-48 bg-gradient-to-r from-iesu-red to-red-900 relative">
        <div className="absolute inset-0 bg-black/10"></div>
      </div>
      <div className="px-8 pb-8 relative">
        <div className="w-32 h-32 rounded-full border-4 border-white bg-white shadow-lg absolute -top-16 left-8 overflow-hidden">
          <img src={user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name)}&background=132A49&color=fff&size=200`} alt={user?.name} className="w-full h-full object-cover" />
        </div>
        
        <div className="ml-40 pt-4 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-black text-gray-900 flex items-center gap-2">
              {user?.name}
            </h1>
            <p className="text-lg text-gray-600 font-medium mt-1">{user?.department}</p>
            {user?.faculty && <p className="text-sm text-gray-500 font-medium">{user?.faculty}</p>}
            {user?.program && <p className="text-sm text-gray-500">{user?.program}</p>}
            <p className="text-gray-500 text-sm mt-0.5">
              Sınıf: {user?.year || 'Belirtilmemiş'} 
              {user?.doubleMajor && ` • ÇAP: ${user?.doubleMajor}`}
              {user?.minor && ` • Yandal: ${user?.minor}`}
            </p>
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takipçi</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takip Edilen</span>
              </div>
            </div>
          </div>
          {currentUser?.id !== user?.id && (
            <div className="flex gap-3">
              <button 
                onClick={() => setIsFollowing(!isFollowing)} 
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition shadow-sm border-2 ${isFollowing ? 'bg-white border-iesu-red text-iesu-red hover:bg-red-50' : 'bg-iesu-red border-iesu-red hover:bg-red-700 text-white'}`}
              >
                {isFollowing ? <><UserCheck size={18} /> Takip Ediliyor</> : <><UserPlus size={18} /> Takip Et</>}
              </button>
              <button onClick={handleMessage} className="flex items-center gap-2 px-6 py-2.5 bg-white border-2 border-gray-200 hover:border-gray-300 text-gray-700 rounded-xl font-bold transition shadow-sm">
                <MessageSquare size={18} /> Mesaj Gönder
              </button>
            </div>
          )}
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <section>
              <h3 className="text-lg font-black text-gray-900 mb-4 flex items-center gap-2"><FileText size={20} className="text-iesu-red" /> Hakkında</h3>
              <p className="text-gray-600 leading-relaxed bg-gray-50 p-6 rounded-2xl">{user?.bio || 'Bu kullanıcı henüz hakkında bir bilgi eklememiş.'}</p>
            </section>
            
            <section>
              <h3 className="text-lg font-black text-gray-900 mb-4 flex items-center gap-2"><GraduationCap size={20} className="text-iesu-red" /> Eğitim Bilgileri</h3>
              <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center text-iesu-red shrink-0">
                    <GraduationCap size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 text-base">İstanbul Esenyurt Üniversitesi</h4>
                    <p className="text-gray-600 text-sm font-medium">{user?.department}</p>
                    <p className="text-gray-400 text-xs mt-1">Sınıf: {user?.year}</p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAlumniProfile = () => (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
      <div className="h-48 bg-gradient-to-r from-teal-700 to-teal-900 relative"></div>
      <div className="px-8 pb-8 relative">
        <div className="w-32 h-32 rounded-full border-4 border-white bg-white shadow-lg absolute -top-16 left-8 overflow-hidden">
          <img src={user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name)}&background=0F766E&color=fff&size=200`} alt={user?.name} className="w-full h-full object-cover" />
        </div>
        
        <div className="ml-40 pt-4 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-black text-gray-900 flex items-center gap-2">
              {user?.name} <Badge type="success">Mezun</Badge>
            </h1>
            <p className="text-lg text-gray-600 font-medium mt-1">{user?.title || 'Mezun'} {user?.company && `at ${user?.company}`}</p>
            <p className="text-gray-500 text-sm mt-0.5">{user?.department} • {user?.gradYear} Mezunu</p>
            {user?.faculty && <p className="text-sm text-gray-500 font-medium">{user?.faculty}</p>}
            {user?.program && <p className="text-sm text-gray-500">{user?.program}</p>}
            {(user?.doubleMajor || user?.minor) && (
              <p className="text-gray-500 text-sm mt-0.5">
                {user?.doubleMajor && `ÇAP: ${user?.doubleMajor}`}
                {user?.doubleMajor && user?.minor && ' • '}
                {user?.minor && `Yandal: ${user?.minor}`}
              </p>
            )}
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takipçi</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takip Edilen</span>
              </div>
            </div>
          </div>
          {currentUser?.id !== user?.id && (
            <div className="flex gap-3">
              <button 
                onClick={() => setIsFollowing(!isFollowing)} 
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition shadow-sm border-2 ${isFollowing ? 'bg-teal-50 border-teal-600 text-teal-600' : 'bg-teal-600 border-teal-600 text-white hover:bg-teal-700'}`}
              >
                {isFollowing ? <><UserCheck size={18} /> Takip Ediliyor</> : <><UserPlus size={18} /> Takip Et</>}
              </button>
              <button onClick={handleMessage} className="flex items-center gap-2 px-6 py-2.5 bg-white border-2 border-gray-200 hover:border-gray-300 text-gray-700 rounded-xl font-bold transition shadow-sm">
                <MessageSquare size={18} /> Mesaj Gönder
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderCompanyProfile = () => (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
      <div className="h-48 bg-gradient-to-r from-blue-700 to-blue-900 relative"></div>
      <div className="px-8 pb-8 relative">
        <div className="w-32 h-32 rounded-2xl border-4 border-white bg-white shadow-lg absolute -top-16 left-8 overflow-hidden flex items-center justify-center">
          <img src={user.logo || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name)}&background=2563EB&color=fff&size=200`} alt={user?.name} className="w-full h-full object-cover" />
        </div>
        
        <div className="ml-40 pt-4 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-black text-gray-900 flex items-center gap-2">
              {user?.name} {user.status === 'Onaylı' && <CheckCircle2 className="text-blue-500" size={24} />}
            </h1>
            <p className="text-lg text-gray-600 font-medium mt-1">{user.sector || 'Sektör Belirtilmemiş'}</p>
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takipçi</span>
              </div>
            </div>
          </div>
          {currentUser?.id !== user?.id && (
            <div className="flex gap-3">
              <button 
                onClick={() => setIsFollowing(!isFollowing)} 
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition shadow-sm border-2 ${isFollowing ? 'bg-blue-50 border-blue-600 text-blue-600' : 'bg-blue-600 border-blue-600 text-white hover:bg-blue-700'}`}
              >
                {isFollowing ? <><UserCheck size={18} /> Takip Ediliyor</> : <><UserPlus size={18} /> Takip Et</>}
              </button>
              <button onClick={handleMessage} className="flex items-center gap-2 px-6 py-2.5 bg-white border-2 border-gray-200 hover:border-gray-300 text-gray-700 rounded-xl font-bold transition shadow-sm">
                <MessageSquare size={18} /> İletişime Geç
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderAcademicProfile = () => (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
      <div className="h-48 bg-gradient-to-r from-slate-700 to-slate-900 relative"></div>
      <div className="px-8 pb-8 relative">
        <div className="w-32 h-32 rounded-full border-4 border-white bg-white shadow-lg absolute -top-16 left-8 overflow-hidden flex items-center justify-center">
          <img src={user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name)}&background=475569&color=fff&size=200`} alt={user?.name} className="w-full h-full object-cover" />
        </div>
        
        <div className="ml-40 pt-4 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-black text-gray-900 flex items-center gap-2">
              {user?.name}
            </h1>
            <p className="text-lg text-gray-600 font-medium mt-1">{user?.title || 'Akademik Personel'}</p>
            <p className="text-gray-500 text-sm mt-0.5">{user?.department || 'Bölüm Belirtilmemiş'}</p>
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takipçi</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                <span className="font-black text-gray-900">0</span>
                <span className="text-gray-500 font-medium">Takip Edilen</span>
              </div>
            </div>
          </div>
          {currentUser?.id !== user?.id && (
            <div className="flex gap-3">
              <button 
                onClick={() => setIsFollowing(!isFollowing)} 
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition shadow-sm border-2 ${isFollowing ? 'bg-slate-50 border-slate-700 text-slate-700' : 'bg-slate-700 border-slate-700 text-white hover:bg-slate-800'}`}
              >
                {isFollowing ? <><UserCheck size={18} /> Takip Ediliyor</> : <><UserPlus size={18} /> Takip Et</>}
              </button>
              <button onClick={handleMessage} className="flex items-center gap-2 px-6 py-2.5 bg-white border-2 border-gray-200 hover:border-gray-300 text-gray-700 rounded-xl font-bold transition shadow-sm">
                <MessageSquare size={18} /> Mesaj Gönder
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-[1000px] mx-auto px-4 lg:px-8 h-16 flex items-center">
          <button onClick={() => setView(previousView || (userRole ? (userRole === 'admin' ? 'admin' : userRole) : 'landing'))} className="flex items-center gap-2 text-gray-600 hover:text-iesu-red font-bold transition-colors">
            <ArrowLeft size={20} /> Geri
          </button>
        </div>
      </nav>

      <main className="max-w-[1000px] mx-auto px-4 lg:px-8 pt-8">
        {userType === 'student' && renderStudentProfile()}
        {userType === 'alumni' && renderAlumniProfile()}
        {userType === 'company' && renderCompanyProfile()}
        {userType === 'academic' && renderAcademicProfile()}
        {userType === 'admin' && (
          <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden p-12 text-center">
            <div className="w-24 h-24 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4 border border-red-100">
              <CheckCircle2 size={40} className="text-red-600" />
            </div>
            <h2 className="text-2xl font-black text-gray-900 mb-2">{user?.name || 'Sistem Yöneticisi'}</h2>
            <p className="text-gray-500">Yönetici hesapları için genel görünüm profili bulunmamaktadır.</p>
          </div>
        )}
        
        {/* User Posts Section */}
        <div className="mt-8 mb-12">
          <h2 className="text-xl font-black text-gray-900 mb-6 flex items-center gap-2">
            <BookOpen size={24} className="text-iesu-red" />
            Gönderiler
          </h2>
          <div className="space-y-6">
            {(() => {
              const userPosts = posts.filter(p => p.author === user?.name || p.author?.name === user?.name || p.company === user?.name);
              if (userPosts.length === 0) {
                return (
                  <div className="bg-white border border-gray-100 rounded-2xl p-12 text-center shadow-sm">
                    <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageSquare size={24} className="text-gray-400" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-1">Henüz bir gönderisi yok</h3>
                    <p className="text-gray-500 text-sm">Kullanıcı herhangi bir gönderi paylaşmadı.</p>
                  </div>
                );
              }
              return userPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ));
            })()}
          </div>
        </div>
      </main>
    </div>
  );
}
