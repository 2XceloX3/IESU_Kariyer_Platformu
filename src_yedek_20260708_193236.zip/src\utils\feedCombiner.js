export function combineFeedItems(posts, events, news, announcements, jobs) {
  const combined = [...(posts || [])];

  const adminAuthor = {
    name: 'Kariyer Geliştirme Ofisi',
    role: 'admin',
    avatar: 'https://ui-avatars.com/api/?name=KGO&background=132A49&color=fff',
    title: 'Süper Yönetici'
  };

  if (events) {
    events.filter(e => e.status !== 'Taslak' && e.status !== 'Pasif').forEach(e => {
      combined.push({
        id: e.id,
        author: { ...adminAuthor, title: 'Etkinlik Duyurusu' },
        content: `${e.title}\n\n${e.description || ''}\n\n📅 ${e.date || ''} ${e.time || ''}\n📍 ${e.location || ''}`,
        image: e.imageUrl || null,
        time: 'Yakın Zamanda',
        likes: Math.floor(Math.random() * 50) + 10,
        comments: Math.floor(Math.random() * 10),
      });
    });
  }

  if (news) {
    news.filter(n => n.status !== 'Taslak' && n.status !== 'Pasif').forEach(n => {
      combined.push({
        id: n.id,
        author: { ...adminAuthor, title: 'Üniversite Haberleri' },
        content: `${n.title}\n\n${n.description || ''}`,
        image: n.imageUrl || null,
        time: 'Yakın Zamanda',
        likes: Math.floor(Math.random() * 80) + 20,
        comments: Math.floor(Math.random() * 15),
      });
    });
  }

  if (announcements) {
    announcements.filter(a => a.status !== 'Taslak' && a.status !== 'Pasif').forEach(a => {
      combined.push({
        id: a.id,
        author: { ...adminAuthor, title: 'Genel Duyuru' },
        content: `📢 ${a.title}\n\n${a.description || ''}`,
        pdf: (a.attachmentData || a.attachments) ? true : false,
        time: 'Yakın Zamanda',
        likes: Math.floor(Math.random() * 30) + 5,
        comments: 0,
      });
    });
  }

  if (jobs) {
    jobs.filter(j => j.status !== 'Taslak' && j.status !== 'Pasif').forEach(j => {
      combined.push({
        id: j.id,
        author: { ...adminAuthor, title: 'Kariyer Fırsatı' },
        content: `💼 YENİ İLAN: ${j.title}\n🏢 ${j.company || 'Firma'}\n📍 ${j.location || 'Konum'}\n\n${j.description || ''}`,
        image: j.imageUrl || j.companyLogo || null,
        isJob: true,
        time: 'Yakın Zamanda',
        likes: Math.floor(Math.random() * 40) + 5,
        comments: Math.floor(Math.random() * 5),
      });
    });
  }

  // Very simple desc sort by ID (assuming IDs have timestamps like POST-12345 or NE-E12345)
  return combined.sort((a, b) => {
    const aId = a.id.replace(/\D/g, '');
    const bId = b.id.replace(/\D/g, '');
    return Number(bId) - Number(aId);
  });
}

