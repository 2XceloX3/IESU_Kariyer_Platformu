import React, { useState } from 'react';
import { ArrowLeft, Bell, Briefcase, Calendar, CheckCircle2, MessageSquare, Star, Info, Trash2, CheckCircle } from 'lucide-react';

export default function NotificationsPanel({ userRole, notifications, setNotifications, currentUser, setView }) {
  
  const myNotifications = (notifications || []).filter(n => n.userId === currentUser?.id).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  const unreadCount = (myNotifications || []).filter(n => !n.read).length;

  const getIcon = (type) => {
    switch(type) {
      case 'message': return <MessageSquare size={18} className="text-blue-500" />;
      case 'application': return <Briefcase size={18} className="text-emerald-500" />;
      case 'event': return <Calendar size={18} className="text-purple-500" />;
      case 'system': return <Info size={18} className="text-iesu-red" />;
      default: return <Bell size={18} className="text-gray-500" />;
    }
  };

  const markAllAsRead = () => {
    const updated = (notifications || []).map(n => n.userId === currentUser?.id ? { ...n, read: true } : n);
    setNotifications(updated);
  };

  const handleNotificationClick = (id, link) => {
    const updated = (notifications || []).map(n => n.id === id ? { ...n, read: true } : n);
    setNotifications(updated);
    if (link) {
      setView(link); // Optional handling to route to specific view based on notification
    }
  };

  const handleDelete = (id, e) => {
    e.stopPropagation();
    const updated = (notifications || []).filter(n => n.id !== id);
    setNotifications(updated);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-[800px] mx-auto px-4 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setView(userRole === 'admin' ? 'admin' : userRole === 'employer' ? 'company' : userRole || 'landing')} className="flex items-center gap-2 text-gray-600 hover:text-iesu-red font-bold transition-colors">
              <ArrowLeft size={20} /> Geri
            </button>
            <div className="h-6 w-[1px] bg-gray-200 mx-2 hidden sm:block"></div>
            <h1 className="text-xl font-black text-gray-900 flex items-center gap-2">
              Bildirimler
            </h1>
          </div>
          {unreadCount > 0 && (
            <button onClick={markAllAsRead} className="text-sm font-bold text-gray-500 hover:text-iesu-red flex items-center gap-1 transition">
              <CheckCircle size={16} /> Tümünü Okundu İşaretle
            </button>
          )}
        </div>
      </nav>

      <main className="max-w-[800px] mx-auto px-4 lg:px-8 pt-8">
        <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
          {myNotifications.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                <Bell size={24} className="text-gray-400" />
              </div>
              <h3 className="text-lg font-black text-gray-900 mb-2">Henüz bildiriminiz bulunmuyor.</h3>
              <p className="text-gray-500 text-sm">Size gelen önemli güncellemeler burada listelenecektir.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {(myNotifications || []).map(notification => (
                <div 
                  key={notification.id} 
                  onClick={() => handleNotificationClick(notification.id, notification.link)}
                  className={`p-6 flex items-start gap-4 transition cursor-pointer relative group ${!notification.read ? 'bg-red-50/30 hover:bg-red-50/50' : 'hover:bg-gray-50'}`}
                >
                  <div className="w-10 h-10 rounded-xl bg-white border border-gray-100 flex items-center justify-center shadow-sm shrink-0">
                    {getIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0 pr-8">
                    <h4 className={`text-sm mb-1 ${!notification.read ? 'font-black text-gray-900' : 'font-bold text-gray-800'}`}>
                      {notification.title}
                    </h4>
                    <p className={`text-sm ${!notification.read ? 'text-gray-700' : 'text-gray-500'}`}>
                      {notification.description}
                    </p>
                    <span className="text-xs text-gray-400 mt-2 block">
                      {new Date(notification.timestamp).toLocaleString('tr-TR')}
                    </span>
                  </div>
                  {!notification.read && (
                    <div className="w-2 h-2 rounded-full bg-iesu-red shrink-0 absolute right-6 top-8"></div>
                  )}
                  <button 
                    onClick={(e) => handleDelete(notification.id, e)}
                    className="absolute right-6 top-6 p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}


