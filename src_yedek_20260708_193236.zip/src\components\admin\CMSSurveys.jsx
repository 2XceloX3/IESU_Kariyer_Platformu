import React, { useState } from 'react';
import { ClipboardList, Edit, Trash2, Plus, Search, Filter, CheckCircle2, Download, Table, BarChart3, Target } from 'lucide-react';
import AdminCMSLayout, { TopInfoCard, Badge } from './AdminCMSLayout';

export default function CMSSurveys({ surveys = [], setSurveys }) {
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const [form, setForm] = useState({
    title: '',
    date: '',
    status: 'Aktif',
    targetAudience: 'Tümü', // 'Öğrenciler', 'Mezunlar', 'Tümü'
    description: '',
    questions: [
      { id: 'q1', text: 'Kariyer Merkezi hizmetlerinden genel olarak memnun musunuz?', type: 'likert' }
    ]
  });

  const handleAddNew = () => {
    setForm({
      title: '',
      date: new Date().toISOString().split('T')[0],
      status: 'Aktif',
      targetAudience: 'Tümü',
      description: '',
      questions: [{ id: 'q1', text: '', type: 'likert' }]
    });
    setCurrentId(null);
    setIsEditing(true);
  };

  const handleEdit = (survey) => {
    setForm({ 
      ...survey,
      questions: survey.questions || [{ id: 'q1', text: 'Soru 1', type: 'likert' }]
    });
    setCurrentId(survey.id);
    setIsEditing(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("Bu anketi silmek istediğinize emin misiniz?")) {
      setSurveys((surveys || []).filter(s => s.id !== id));
    }
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!form.title) return alert("Anket başlığı zorunludur.");

    if (currentId) {
      setSurveys((surveys || []).map(s => s.id === currentId ? { ...s, ...form, updatedAt: new Date().toISOString() } : s));
    } else {
      setSurveys([{ 
        ...form, 
        id: 'SRV-' + Date.now(), 
        responses: 0, 
        total: 100, // Dummy target
        createdAt: new Date().toISOString() 
      }, ...surveys]);
    }
    setIsEditing(true);
    alert('Anket kaydedildi.');
    setIsEditing(false);
  };

  const addQuestion = () => {
    setForm(prev => ({
      ...prev,
      questions: [...prev.questions, { id: 'q' + Date.now(), text: '', type: 'likert' }]
    }));
  };

  const updateQuestion = (id, text) => {
    setForm(prev => ({
      ...prev,
      questions: prev.questions.map(q => q.id === id ? { ...q, text } : q)
    }));
  };

  const removeQuestion = (id) => {
    if (form.questions.length === 1) return alert("En az 1 soru olmalıdır.");
    setForm(prev => ({
      ...prev,
      questions: prev.questions.filter(q => q.id !== id)
    }));
  };

  const handleSpssExport = (survey) => {
    // Generate dummy SPSS/CSV content
    const csvContent = "data:text/csv;charset=utf-8," 
      + "ID,Cinsiyet,Bolum,Soru1_Likert,Soru2_Likert,Soru3_Likert\n"
      + "1,1,Bilgisayar,5,4,5\n"
      + "2,2,Isletme,3,4,4\n"
      + "3,1,Endustri,5,5,4\n"
      + "4,2,Mimarlik,4,2,3\n";
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `SPSS_Export_${survey.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert("SPSS / Excel uyumlu veri başarıyla indirildi. (Mock Data)");
  };

  const filtered = (surveys || []).filter(s => {
    const matchQ = (s.title||'').toLowerCase().includes(searchQuery.toLowerCase());
    const matchS = statusFilter === 'all' || (s.status||'').toLowerCase() === statusFilter.toLowerCase();
    return matchQ && matchS;
  });

  const activeCount = (surveys || []).filter(s => s.status === 'Aktif').length;

  const listView = (
    <div className="space-y-6">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">Form ve Anket Yönetimi</h2>
          <p className="text-sm font-medium text-gray-500 mt-1">Öğrenci ve mezun anketlerini yönetin, SPSS uyumlu dışa aktarın.</p>
        </div>
        <button onClick={handleAddNew} className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 shadow-sm transition-all hover:shadow-md">
          <Plus size={18} /> Yeni Anket
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <TopInfoCard icon={<ClipboardList size={20} />} title="Toplam Anket" value={(surveys || []).length} color="blue" />
        <TopInfoCard icon={<CheckCircle2 size={20} />} title="Aktif Anketler" value={activeCount} color="emerald" />
        <TopInfoCard icon={<BarChart3 size={20} />} title="Toplam Yanıt" value={(surveys || []).reduce((acc, s) => acc + (s.responses || 0), 0)} color="purple" />
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_rgb(0,0,0,0.03)] overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex flex-wrap gap-4 bg-gray-50/50">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
            <input type="text" placeholder="Anket başlığında ara..." value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-red-500/20" />
          </div>
          <div className="flex gap-2">
            <select value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} className="bg-white border border-gray-200 rounded-xl px-4 py-2 text-sm font-medium focus:ring-2 focus:ring-red-500/20">
              <option value="all">Tüm Durumlar</option>
              <option value="Aktif">Aktif</option>
              <option value="Kapandı">Kapandı</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-gray-50/50 text-gray-500 font-bold text-[11px] uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 rounded-tl-2xl">Anket Başlığı</th>
                <th className="px-6 py-4">Tarih</th>
                <th className="px-6 py-4">Yanıt / Hedef</th>
                <th className="px-6 py-4">Durum</th>
                <th className="px-6 py-4 rounded-tr-2xl text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map(s => (
                <tr key={s.id} className="hover:bg-gray-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="font-bold text-gray-900">{s.title}</div>
                    <div className="text-xs text-gray-500 mt-1">{s.id}</div>
                  </td>
                  <td className="px-6 py-4 text-gray-600 font-medium">{s.date}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-blue-600">{s.responses || 0}</span>
                      <span className="text-gray-400">/ {s.total || 0}</span>
                    </div>
                    <div className="w-24 h-1.5 bg-gray-100 rounded-full mt-1">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.min(100, ((s.responses || 0) / (s.total || 1)) * 100)}%` }}></div>
                    </div>
                  </td>
                  <td className="px-6 py-4"><Badge status={s.status} /></td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => handleSpssExport(s)} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition tooltip" title="SPSS Dışa Aktar">
                        <Download size={16} />
                      </button>
                      <button onClick={() => handleEdit(s)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition" title="Düzenle">
                        <Edit size={16} />
                      </button>
                      <button onClick={() => handleDelete(s.id)} className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition" title="Sil">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan="5" className="px-6 py-12 text-center text-gray-500">
                    <ClipboardList size={32} className="mx-auto text-gray-300 mb-3" />
                    <p className="font-medium">Kayıt bulunamadı.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const formView = (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1 bg-white border border-gray-100 rounded-2xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
          <h3 className="text-lg font-black text-gray-900">{currentId ? 'Anketi Düzenle' : 'Yeni Anket Oluştur'}</h3>
          <button type="button" onClick={() => setIsEditing(false)} className="text-sm font-bold text-gray-500 hover:text-gray-900 transition">İptal</button>
        </div>

        <form onSubmit={handleSave} className="space-y-5">
          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Anket Başlığı <span className="text-red-500">*</span></label>
            <input type="text" value={form.title} onChange={e=>setForm({...form, title: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: Mezun İstihdam Anketi" required />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Hedef Kitle</label>
              <select value={form.targetAudience} onChange={e=>setForm({...form, targetAudience: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20">
                <option>Tümü</option>
                <option>Öğrenciler</option>
                <option>Mezunlar</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Durum</label>
              <select value={form.status} onChange={e=>setForm({...form, status: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20">
                <option>Aktif</option>
                <option>Kapandı</option>
                <option>Taslak</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Açıklama</label>
            <textarea value={form.description} onChange={e=>setForm({...form, description: e.target.value})} rows={3} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-red-500/20 resize-none" placeholder="Anketin amacı..."></textarea>
          </div>

          <div className="pt-4 border-t border-gray-100">
            <div className="flex justify-between items-center mb-4">
              <label className="text-sm font-black text-gray-900 block flex items-center gap-2"><Target size={18} className="text-blue-600" /> Likert Soruları (1-5)</label>
              <button type="button" onClick={addQuestion} className="text-xs font-bold bg-blue-50 text-blue-600 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition flex items-center gap-1">
                <Plus size={14} /> Soru Ekle
              </button>
            </div>
            
            <div className="space-y-3">
              {(form.questions || []).map((q, index) => (
                <div key={q.id} className="flex items-start gap-3 bg-gray-50 p-3 rounded-xl border border-gray-100">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-black text-xs shrink-0 mt-0.5">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <input 
                      type="text" 
                      value={q.text} 
                      onChange={(e) => updateQuestion(q.id, e.target.value)} 
                      placeholder="Soru metnini giriniz..." 
                      className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                    <p className="text-[10px] text-gray-400 mt-1 font-medium ml-1">Tip: 1'den 5'e Likert (Kesinlikle Katılmıyorum ➜ Kesinlikle Katılıyorum)</p>
                  </div>
                  <button type="button" onClick={() => removeQuestion(q.id)} className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition mt-0.5">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t border-gray-100 mt-8">
            <button type="button" onClick={() => setIsEditing(false)} className="px-6 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-bold transition">İptal</button>
            <button type="submit" className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold transition shadow-sm">
              {currentId ? 'Değişiklikleri Kaydet' : 'Anketi Oluştur'}
            </button>
          </div>
        </form>
      </div>
      
      <div className="w-full lg:w-80 space-y-4">
        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-5">
          <h4 className="font-bold text-blue-900 flex items-center gap-2 text-sm"><CheckCircle2 size={16} /> KVKK Uyumu</h4>
          <p className="text-xs text-blue-800/80 mt-2 leading-relaxed">
            Oluşturduğunuz anketlerin yanıtları tamamen <span className="font-bold">anonim</span> olarak toplanır. Kullanıcıların kimlik bilgileri yanıtlara bağlanmaz ve SPSS çıktılarında sadece sayısal kodlamalar yer alır.
          </p>
        </div>
        <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-5">
          <h4 className="font-bold text-emerald-900 flex items-center gap-2 text-sm"><Table size={16} /> SPSS Formatı</h4>
          <p className="text-xs text-emerald-800/80 mt-2 leading-relaxed">
            Dışa aktarım yapıldığında sistem; <b>Codebook</b> ve verileri otomatik olarak sayısal (.csv formatında 1, 2, 3, 4, 5) hazırlayacaktır.
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="animate-fade-in">
      {isEditing ? formView : listView}
    </div>
  );
}
