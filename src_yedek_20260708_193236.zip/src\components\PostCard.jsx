import React, { useState } from 'react';
import { MoreHorizontal, Heart, MessageCircle, Bookmark, Send, Briefcase, FileText, Download, ShieldCheck } from 'lucide-react';

export default function PostCard({ post }) {
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    setComments([...comments, { id: Date.now(), text: newComment, author: 'Siz', time: 'Şimdi' }]);
    setNewComment('');
  };

  return (
    <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-[var(--border-soft)] shadow-[var(--shadow-soft)] overflow-hidden transition-all hover:shadow-lg">
      {/* Header */}
      <div className="p-4 flex justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer group">
          {post?.author?.role === 'admin' ? (
            <div className="w-11 h-11 rounded-full bg-red-50 flex items-center justify-center shadow-sm border border-red-100 shrink-0">
              <ShieldCheck size={20} className="text-red-600" />
            </div>
          ) : (
            <img src={post?.author?.avatar || `https://ui-avatars.com/api/?name=U&background=132A49&color=fff`} alt="Author" className="w-11 h-11 rounded-full object-cover shadow-sm border border-gray-100 shrink-0" />
          )}
          <div>
            <h3 className="font-bold text-[15px] text-gray-900 group-hover:text-iesu-red transition-colors flex items-center gap-1.5">
              {post?.author?.role === 'admin' ? 'Kariyer Geliştirme Ofisi' : (post?.author?.name || 'Kullanıcı')}
              {post?.author?.role === 'admin' && <ShieldCheck size={14} className="text-emerald-500" />}
            </h3>
            <p className="text-[12px] text-gray-500 font-medium">
              {post?.author?.role === 'admin' ? 'Süper Yönetici' : (post?.author?.title || '')} • {post?.time || ''}
            </p>
          </div>
        </div>
        <button className="text-gray-400 hover:text-gray-600 p-2 rounded-xl hover:bg-gray-50 transition">
          <MoreHorizontal size={20} />
        </button>
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <p className="text-[15px] text-gray-800 font-medium leading-snug whitespace-pre-wrap">{post.content}</p>
      </div>

      {/* Media Attachments */}
      {post.image && (
        <div className="w-full aspect-video bg-gray-100 relative group cursor-pointer overflow-hidden border-y border-gray-50">
          <img src={post.image} alt="Post Cover" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
          {post.isJob && (
            <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-[12px] font-bold flex items-center gap-1.5">
              <Briefcase size={14} /> İLAN
            </div>
          )}
        </div>
      )}

      {post.video && (
        <div className="w-full bg-black relative border-y border-gray-50">
          <video src={post.video} controls className="w-full max-h-96" />
        </div>
      )}

      {post.pdf && (
        <div className="mx-4 mb-4 mt-2 p-4 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-between hover:bg-red-50 transition group cursor-pointer">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
              <FileText className="text-red-500" size={20} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-gray-900 group-hover:text-red-600 transition">Ekli Döküman.pdf</h4>
              <p className="text-[11px] text-gray-500 font-medium">PDF Belgesi</p>
            </div>
          </div>
          <button className="w-8 h-8 rounded-full bg-white text-gray-500 flex items-center justify-center shadow-sm hover:text-red-600 transition">
            <Download size={16} />
          </button>
        </div>
      )}

      {/* Actions */}
      <div className="p-2 flex items-center justify-between border-t border-gray-50 bg-gray-50/30">
        <div className="flex gap-1">
          <button 
            onClick={() => setLiked(!liked)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all font-bold text-[14px] ${liked ? 'text-white bg-gradient-to-r from-[var(--brand-pomegranate)] to-[var(--brand-red-dark)] shadow-md hover:shadow-lg' : 'text-gray-600 hover:bg-[var(--brand-soft-red)] hover:text-[var(--brand-pomegranate)]'}`}
          >
            <Heart size={20} className={liked ? 'fill-current' : ''} /> 
            <span className="hidden sm:inline">{post.likes + (liked ? 1 : 0)}</span>
          </button>
          <button 
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-2 px-4 py-2 hover:bg-[var(--surface-soft)] rounded-xl text-gray-600 transition-colors font-bold text-[14px]">
            <MessageCircle size={20} className="text-gray-400" /> <span className="hidden sm:inline">{post.comments + comments.length}</span>
          </button>
        </div>
        <div className="flex gap-1">
          <button 
            onClick={() => setBookmarked(!bookmarked)}
            className={`p-2 rounded-xl transition-colors ${bookmarked ? 'text-amber-500 bg-amber-50' : 'text-gray-400 hover:bg-gray-100 hover:text-gray-600'}`}
          >
            <Bookmark size={22} className={bookmarked ? 'fill-current' : ''} />
          </button>
          <button className="p-2 hover:bg-gray-100 rounded-xl text-gray-400 hover:text-gray-600 transition-colors">
            <Send size={22} />
          </button>
        </div>
      </div>
      
      {/* Fast Action for Jobs */}
      {post.isJob && (
        <div className="px-4 pb-4">
          <button className="w-full bg-gradient-to-r from-[var(--brand-pomegranate)] to-[var(--brand-red-dark)] hover:shadow-lg text-white font-bold py-3.5 rounded-2xl transition-all flex justify-center items-center gap-2 active:scale-[0.98]">
            <Briefcase size={18} /> Hemen Başvur
          </button>
        </div>
      )}

      {/* Comments Section */}
      {showComments && (
        <div className="px-4 pb-4 border-t border-gray-100 bg-gray-50/50 pt-4">
          <div className="space-y-3 mb-4">
            {comments.map(comment => (
              <div key={comment.id} className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center shrink-0 overflow-hidden">
                  <img src={`https://ui-avatars.com/api/?name=${comment.author}&background=132A49&color=fff`} alt={comment.author} />
                </div>
                <div className="bg-white px-4 py-2.5 rounded-2xl rounded-tl-none shadow-sm border border-gray-100 flex-1">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-bold text-[13px] text-gray-900">{comment.author}</span>
                    <span className="text-[11px] text-gray-400 font-medium">{comment.time}</span>
                  </div>
                  <p className="text-[14px] text-gray-700 leading-snug">{comment.text}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-3 relative">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center shrink-0 overflow-hidden">
              <img src="https://ui-avatars.com/api/?name=Siz&background=red&color=fff" alt="Siz" />
            </div>
            <input 
              type="text" 
              placeholder="Bir yorum yaz..." 
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
              className="flex-1 bg-white border border-gray-200 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-red-400 focus:ring-1 focus:ring-red-400 transition pr-10"
            />
            <button 
              onClick={handleAddComment}
              disabled={!newComment.trim()}
              className="absolute right-1 w-8 h-8 flex items-center justify-center bg-iesu-red text-white rounded-full disabled:opacity-50 disabled:bg-gray-300 transition-colors"
            >
              <Send size={14} className="ml-0.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
