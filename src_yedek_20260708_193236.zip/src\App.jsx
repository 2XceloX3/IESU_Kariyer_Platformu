import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import Login from './components/Login';
import Register from './components/Register';
import ForgotPassword from './components/ForgotPassword';
import StudentFeed from './components/StudentFeed';
import CompanyFeed from './components/CompanyFeed';
import AdminDashboard from './components/AdminDashboard';
import OrganizationChart from './components/OrganizationChart';
import JobsAndInternships from './components/JobsAndInternships';
import NewsEvents from './components/NewsEvents';
import SemPanel from './components/SemPanel';
import StajPanel from './components/StajPanel';
import { generateStudents, generateAlumni, generateCompanies, initialSemCourses, initialJobs, initialFeatured, initialMentorships, initialVoluntaryInternships, initialAcademicCatalog, initialAcademicApprovals, initialNews, initialEvents, initialAnnouncements } from './utils/mockData';
import useLocalStorageState from './utils/useLocalStorageState';
import { contentData } from './components/NewsEvents';
import AlumniFeed from './components/AlumniFeed';
import AcademicStaffFeed from './components/AcademicStaffFeed';
import ProfileUpdate from './components/ProfileUpdate';
import UserProfile from './components/UserProfile';
import GroupProfile from './components/GroupProfile';
import NotificationsPanel from './components/NotificationsPanel';
import CalendarView from './components/CalendarView';
import ApplicationsPanel from './components/ApplicationsPanel';
import AICVBuilder from './components/AICVBuilder';
import MessagingInterface from './components/MessagingInterface';

import ErrorBoundary from './components/ErrorBoundary';


function App() {
  const [viewState, setViewState] = useLocalStorageState('iesu_view_v1', 'landing'); 
  const [previousView, setPreviousView] = useLocalStorageState('iesu_prev_view_v1', 'landing');
  const view = viewState;
  const setView = (newView) => {
    if (['student', 'alumni', 'company', 'academic', 'admin'].includes(view)) {
      setPreviousView(view);
    }
    setViewState(newView);
  };
  const [userRole, setUserRole] = useLocalStorageState('iesu_user_role_v1', null); 
  const [selectedUserId, setSelectedUserId] = useLocalStorageState('iesu_selected_user_id_v1', null);
  const [selectedGroupId, setSelectedGroupId] = useLocalStorageState('iesu_selected_group_id_v1', null);
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('iesu_mock_user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [academicRole, setAcademicRole] = useState('super_admin'); // 'super_admin', 'content_admin', 'mentor_admin', 'standard_academic'

  React.useEffect(() => {
    if (currentUser) {
      localStorage.setItem('iesu_mock_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  // GLOBAL STATE: Canlı Akış Gönderileri (Feed Posts)
  const [posts, setPosts] = useState([]);

  // GLOBAL STATE: Haberler, Duyurular, Etkinlikler, SEM vs.
  const [news, setNews] = useLocalStorageState('iesu_news_v4', initialNews);
  const [announcements, setAnnouncements] = useLocalStorageState('iesu_announcements_v4', initialAnnouncements);
  const [events, setEvents] = useLocalStorageState('iesu_events_v4', initialEvents);
  const [semCourses, setSemCourses] = useLocalStorageState('iesu_sem_courses_v4', initialSemCourses);
  const [jobs, setJobs] = useLocalStorageState('iesu_jobs_v4', initialJobs);
  const [featuredOpportunities, setFeaturedOpportunities] = useLocalStorageState('iesu_featured_v2', initialFeatured);
  const [mentorships, setMentorships] = useLocalStorageState('iesu_mentorships_v2', initialMentorships);
  const [voluntaryInternships, setVoluntaryInternships] = useLocalStorageState('iesu_voluntary_internships_v1', initialVoluntaryInternships);
  
  // ALUMNI MODULES STATE
  const [alumniCardApplications, setAlumniCardApplications] = useLocalStorageState('iesu_alumni_card_apps_v1', []);
  const [alumniCardForms, setAlumniCardForms] = useLocalStorageState('iesu_alumni_card_forms_v1', []);

  // Phase 2: Students, Alumni, Companies, Academic Staff
  const [students, setStudents] = useLocalStorageState('iesu_students_v2', []);
  const [alumni, setAlumni] = useLocalStorageState('iesu_alumni_v2', []);
  const [companies, setCompanies] = useLocalStorageState('iesu_companies_v2', []);
  const [academicStaff, setAcademicStaff] = useLocalStorageState('iesu_academic_staff_v2', []);

  // Phase 4: Interactions (Messages, Notifications & Applications)
  const [messages, setMessages] = useLocalStorageState('iesu_messages_v2', []);
  const [notifications, setNotifications] = useLocalStorageState('iesu_notifications_v1', []);
  const [applications, setApplications] = useLocalStorageState('iesu_applications_v2', []);

  // GLOBAL STATE: Anketler (Surveys)
  const [surveys, setSurveys] = useState([]);

  // Phase 10: Academic Data
  const [academicCatalog, setAcademicCatalog] = useLocalStorageState('iesu_academic_catalog_v1', initialAcademicCatalog);
  const [academicApprovals, setAcademicApprovals] = useLocalStorageState('iesu_academic_approvals_v1', initialAcademicApprovals);

  // ─── LIVE DATA FILTER: Remove demo_seed records from all live-facing views ───
  const filterLive = (arr) => (arr || []).filter(item => item.source !== 'demo_seed');
  const liveStudents = filterLive(students);
  const liveAlumni = filterLive(alumni);
  const liveCompanies = filterLive(companies);
  const liveAcademicStaff = filterLive(academicStaff);
  const liveMessages = filterLive(messages);

  return (
    <ErrorBoundary>
      {view === 'landing' && <LandingPage setView={setView} userRole={userRole} setUserRole={setUserRole} />}
      {view === 'login' && <Login setView={setView} setUserRole={setUserRole} setAcademicRole={setAcademicRole} setCurrentUser={setCurrentUser} />}
      {view === 'register' && <Register setView={setView} setCurrentUser={setCurrentUser} />}
      {view === 'forgot_password' && <ForgotPassword setView={setView} />}
      {view === 'student' && <StudentFeed setView={setView} setSelectedUserId={setSelectedUserId} notifications={notifications} setNotifications={setNotifications} posts={posts} setPosts={setPosts} surveys={surveys} userRole={userRole} news={news} events={events} students={liveStudents} alumni={liveAlumni} companies={liveCompanies} currentUser={currentUser} featuredOpportunities={featuredOpportunities} mentorships={mentorships} messages={liveMessages} setMessages={setMessages} applications={applications} setApplications={setApplications} jobs={jobs} academicStaff={liveAcademicStaff} announcements={announcements} academicRole={academicRole} />}
      {view === 'alumni' && <AlumniFeed setView={setView} setSelectedUserId={setSelectedUserId} notifications={notifications} setNotifications={setNotifications} posts={posts} setPosts={setPosts} surveys={surveys} userRole={userRole} news={news} events={events} students={liveStudents} alumni={liveAlumni} companies={liveCompanies} currentUser={currentUser} featuredOpportunities={featuredOpportunities} mentorships={mentorships} messages={liveMessages} setMessages={setMessages} applications={applications} setApplications={setApplications} jobs={jobs} academicStaff={liveAcademicStaff} announcements={announcements} alumniCardApplications={alumniCardApplications} setAlumniCardApplications={setAlumniCardApplications} alumniCardForms={alumniCardForms} academicRole={academicRole} />}
      {view === 'academic' && <AcademicStaffFeed setView={setView} setSelectedUserId={setSelectedUserId} notifications={notifications} setNotifications={setNotifications} posts={posts} setPosts={setPosts} surveys={surveys} userRole={userRole} news={news} events={events} students={liveStudents} alumni={liveAlumni} companies={liveCompanies} currentUser={currentUser} featuredOpportunities={featuredOpportunities} mentorships={mentorships} messages={liveMessages} setMessages={setMessages} applications={applications} setApplications={setApplications} jobs={jobs} academicStaff={liveAcademicStaff} announcements={announcements} academicRole={academicRole} />}
      {view === 'company' && <CompanyFeed setView={setView} setSelectedUserId={setSelectedUserId} notifications={notifications} setNotifications={setNotifications} posts={posts} setPosts={setPosts} surveys={surveys} news={news} events={events} students={liveStudents} alumni={liveAlumni} companies={liveCompanies} messages={liveMessages} setMessages={setMessages} applications={applications} setApplications={setApplications} jobs={jobs} announcements={announcements} academicStaff={liveAcademicStaff} currentUser={currentUser} userRole={userRole} academicRole={academicRole} />}
      {view === 'admin' && <AdminDashboard 
        setView={setView} 
        currentUser={currentUser} setCurrentUser={setCurrentUser}
        userRole={userRole} academicRole={academicRole}
        posts={posts} setPosts={setPosts} 
        news={news} setNews={setNews}
        announcements={announcements} setAnnouncements={setAnnouncements}
        events={events} setEvents={setEvents}
        semCourses={semCourses} setSemCourses={setSemCourses}
        surveys={surveys} setSurveys={setSurveys}
        students={students} setStudents={setStudents}
        alumni={alumni} setAlumni={setAlumni}
        companies={companies} setCompanies={setCompanies}
        academicStaff={academicStaff} setAcademicStaff={setAcademicStaff}
        jobs={jobs} setJobs={setJobs}
        featuredOpportunities={featuredOpportunities} setFeaturedOpportunities={setFeaturedOpportunities}
        mentorships={mentorships} setMentorships={setMentorships}
        voluntaryInternships={voluntaryInternships} setVoluntaryInternships={setVoluntaryInternships}
        messages={messages} setMessages={setMessages}
        applications={applications} setApplications={setApplications}
        academicRole={academicRole}
        academicCatalog={academicCatalog} setAcademicCatalog={setAcademicCatalog}
        academicApprovals={academicApprovals} setAcademicApprovals={setAcademicApprovals}
        alumniCardApplications={alumniCardApplications} setAlumniCardApplications={setAlumniCardApplications}
        alumniCardForms={alumniCardForms} setAlumniCardForms={setAlumniCardForms}
      />}
      {view === 'organization' && <OrganizationChart setView={setView} userRole={userRole} />}
      {view === 'jobs' && <JobsAndInternships setView={setView} jobs={jobs} applications={applications} setApplications={setApplications} currentUser={currentUser} userRole={userRole} />}
      {view === 'haberler' && <NewsEvents setView={setView} category="haberler" news={news} announcements={announcements} events={events} currentUser={currentUser} userRole={userRole} />}
      {view === 'duyurular' && <NewsEvents setView={setView} category="duyurular" news={news} announcements={announcements} events={events} currentUser={currentUser} userRole={userRole} />}
      {view === 'etkinlikler' && <NewsEvents setView={setView} category="etkinlikler" news={news} announcements={announcements} events={events} currentUser={currentUser} userRole={userRole} />}
      {view === 'sem' && <SemPanel setView={setView} semCourses={semCourses} userRole={userRole} />}
      {view === 'staj' && <StajPanel setView={setView} userRole={userRole} />}
      {view === 'profile_update' && <ProfileUpdate 
        setView={setView} 
        currentUser={currentUser} setCurrentUser={setCurrentUser}
        userRole={userRole} 
        academicCatalog={academicCatalog} 
        academicApprovals={academicApprovals} setAcademicApprovals={setAcademicApprovals} 
        students={students} setStudents={setStudents}
        alumni={alumni} setAlumni={setAlumni}
        academicStaff={academicStaff} setAcademicStaff={setAcademicStaff}
        companies={companies} setCompanies={setCompanies}
      />}
      {view === 'user_profile' && <UserProfile 
          userId={selectedUserId} 
          setView={setView} 
          previousView={previousView}
          students={liveStudents} 
          alumni={liveAlumni} 
          companies={liveCompanies} 
          academicStaff={liveAcademicStaff} 
          currentUser={currentUser}
          userRole={userRole}
          posts={posts}
          setPosts={setPosts}
        />}
      {view === 'group_profile' && <GroupProfile
        groupId={selectedGroupId}
        groupData={{}}
        posts={posts}
        setPosts={setPosts}
        currentUser={currentUser}
        setView={setView}
      />}
      {view === 'notifications' && <NotificationsPanel 
        notifications={notifications} 
        setNotifications={setNotifications} 
        currentUser={currentUser} 
        setView={setView}
        userRole={userRole}
      />}
      {view === 'calendar' && <CalendarView 
        events={events} 
        mentorships={mentorships} 
        currentUser={currentUser} 
        userRole={userRole}
        setView={setView} 
        setEvents={setEvents} 
      />}
      {view === 'applications' && <ApplicationsPanel applications={applications} currentUser={currentUser} userRole={userRole} setView={setView} />}
      {view === 'cvbuilder' && <AICVBuilder currentUser={currentUser} userRole={userRole} setView={setView} />}
      {view === 'messaging' && <MessagingInterface messages={messages} setMessages={setMessages} currentUser={currentUser} userRole={userRole} contacts={[...students, ...alumni, ...companies, ...academicStaff]} setView={setView} setSelectedUserId={setSelectedUserId} />}
    </ErrorBoundary>
  );
}

export default App;

