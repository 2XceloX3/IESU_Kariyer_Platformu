import React, { useState } from 'react';
import AdminCMSLayout from './AdminCMSLayout';
import { Users, Edit, Trash2, Plus, Calendar, Search, Filter, BookOpen, Clock, CheckCircle2, Award, UserCheck, GraduationCap } from 'lucide-react';
import MediaUploader from './MediaUploader';
import AttachmentUploader from './AttachmentUploader';

export default function CMSSEMCourses({ semCourses = [], setSemCourses }) {
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const [form, setForm] = useState({
    title: '',
    category: 'Mesleki Gelişim',
    shortDescription: '',
    description: '',
    instructorName: '',
    instructorTitle: '',
    startDate: '',
    endDate: '',
    courseTime: '',
    duration: '',
    location: '',
    quota: '',
    price: '',
    certificateAvailable: true,
    deadline: '',
    status: 'Taslak',
    image: '',
    pdf: null
  });

  const handleAddNew = () => {
    setForm({
      title: '',
      category: 'Mesleki Gelişim',
      shortDescription: '',
      description: '',
      instructorName: '',
      instructorTitle: '',
      startDate: '',
      endDate: '',
      courseTime: '',
      duration: '',
      location: '',
      quota: '',
      price: '',
      certificateAvailable: true,
      deadline: '',
      status: 'Taslak',
      image: '',
      pdf: null
    });
    setCurrentId(null);
    setIsEditing(true);
  };

  const handleEdit = (course) => {
    setForm({ 
      ...course, 
      category: course.category || 'Mesleki Gelişim',
      instructorTitle: course.instructorTitle || '',
      courseTime: course.courseTime || '',
      duration: course.duration || '',
      location: course.location || '',
      price: course.price || '',
      certificateAvailable: course.certificateAvailable ?? true,
      image: course.image || '',
      pdf: course.pdf || null
    });
    setCurrentId(course.id);
    setIsEditing(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("Bu SEM kursunu silmek istediğinize emin misiniz?")) {
      setSemCourses((semCourses || []).filter(c => c.id !== id));
    }
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!form.title || !form.instructorName) return alert("Kurs adı ve eğitmen adı zorunludur.");

    if (currentId) {
      setSemCourses((semCourses || []).map(c => c.id === currentId ? { ...c, ...form, updatedAt: new Date().toISOString() } : c));
    } else {
      setSemCourses([{ ...form, id: 'SEM-' + Date.now(), createdAt: new Date().toISOString() }, ...semCourses]);
    }
    setIsEditing(false);
  };

  const filtered = (semCourses || []).filter(c => {
    const matchQ = (c.title||'').toLowerCase().includes(searchQuery.toLowerCase()) || (c.instructorName||'').toLowerCase().includes(searchQuery.toLowerCase());
    const matchS = statusFilter === 'all' || (c.status||'').toLowerCase() === statusFilter.toLowerCase();
    return matchQ && matchS;
  });

  const activeCount = (semCourses || []).filter(c => c.status === 'Aktif' || c.status === 'Yayında').length;
  const draftCount = (semCourses || []).filter(c => c.status === 'Taslak').length;

  const listView = (
    <div className="space-y-6">
      {/* HEADER & STATS */}
      <div>
        <div className="flex justify-between items-end mb-4">
          <div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">SEM Kurs Yönetimi</h2>
            <p className="text-sm font-medium text-gray-500 mt-1">Sürekli Eğitim Merkezi eğitimlerini ve sertifika programlarını yönetin.</p>
          </div>
          <button onClick={handleAddNew} className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 shadow-sm transition-all hover:shadow-md">
            <Plus size={18} /> Yeni Kurs Ekle
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center"><BookOpen size={24}/></div>
            <div><p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Toplam Eğitim</p><p className="text-2xl font-black text-gray-900">{(semCourses || []).length}</p></div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center"><CheckCircle2 size={24}/></div>
            <div><p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Aktif Eğitimler</p><p className="text-2xl font-black text-gray-900">{activeCount}</p></div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center"><Edit size={24}/></div>
            <div><p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Taslaklar</p><p className="text-2xl font-black text-gray-900">{draftCount}</p></div>
          </div>
        </div>
      </div>

      {/* FILTERS */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input 
            type="text" placeholder="Eğitim başlığı veya eğitmen ara..." 
            className="w-full pl-10 pr-4 py-2 bg-gray-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-red-500/20 transition-all"
            value={searchQuery} onChange={e=>setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} className="bg-gray-50 border-none text-sm font-medium rounded-xl px-4 py-2 focus:ring-2 focus:ring-red-500/20 outline-none cursor-pointer">
            <option value="all">Tüm Durumlar</option>
            <option value="aktif">Aktif</option>
            <option value="yayında">Yayında</option>
            <option value="taslak">Taslak</option>
            <option value="kapalı">Kapalı</option>
          </select>
          <button className="p-2 bg-gray-50 text-gray-600 rounded-xl hover:bg-gray-100 transition"><Filter size={18}/></button>
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 bg-gray-50 text-gray-400 rounded-full flex items-center justify-center mb-4"><GraduationCap size={32}/></div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">Kayıt Bulunamadı</h3>
            <p className="text-sm text-gray-500">Arama kriterlerine uygun eğitim programı bulunmuyor.</p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-100">
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Eğitim</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Eğitmen</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Tarih / Saat</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Durum</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map(c => (
                <tr key={c.id} className="hover:bg-gray-50/50 transition group">
                  <td className="py-3 px-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 overflow-hidden">
                        {c.image ? <img src={c.image} className="w-full h-full object-cover" /> : <GraduationCap size={18} />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900">{c.title}</p>
                        <p className="text-xs font-medium text-gray-500 mt-0.5">{c.category}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-5">
                    <p className="text-sm font-bold text-gray-700">{c.instructorName}</p>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5">{c.instructorTitle || 'EĞİTMEN'}</p>
                  </td>
                  <td className="py-3 px-5">
                    <div className="flex flex-col gap-1 text-xs font-medium text-gray-600">
                      <span className="flex items-center gap-1.5"><Calendar size={13} className="text-gray-400"/> {c.startDate || '?'} - {c.endDate || '?'}</span>
                      <span className="flex items-center gap-1.5"><Clock size={13} className="text-gray-400"/> {c.courseTime || '?'}</span>
                    </div>
                  </td>
                  <td className="py-3 px-5">
                    <span className={`inline-flex px-2.5 py-1 rounded-md text-[11px] font-black uppercase tracking-wider
                      ${(c.status === 'Aktif' || c.status === 'Yayında') ? 'bg-emerald-100 text-emerald-700' : 
                        c.status === 'Taslak' ? 'bg-orange-100 text-orange-700' : 'bg-gray-100 text-gray-600'}`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="py-3 px-5 text-right">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition">
                      <button onClick={() => handleEdit(c)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"><Edit size={16}/></button>
                      <button onClick={() => handleDelete(c.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"><Trash2 size={16}/></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );

  const formView = (
    <div className="flex flex-col lg:flex-row gap-6">
      {/* LEFT: FORM */}
      <div className="flex-1 bg-white border border-gray-100 rounded-2xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
          <h3 className="text-lg font-black text-gray-900">{currentId ? 'Eğitimi Düzenle' : 'Yeni SEM Kursu'}</h3>
          <button type="button" onClick={() => setIsEditing(false)} className="text-sm font-bold text-gray-500 hover:text-gray-900 transition">İptal</button>
        </div>

        <form onSubmit={handleSave} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Kurs Başlığı <span className="text-red-500">*</span></label>
              <input type="text" value={form.title} onChange={e=>setForm({...form, title: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: İleri Seviye Veri Analizi" required />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Eğitmen Adı Soyadı <span className="text-red-500">*</span></label>
              <input type="text" value={form.instructorName} onChange={e=>setForm({...form, instructorName: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" required />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Eğitmen Unvanı</label>
              <input type="text" value={form.instructorTitle} onChange={e=>setForm({...form, instructorTitle: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: Prof. Dr. veya Kıdemli Uzman" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Kategori</label>
              <select value={form.category} onChange={e=>setForm({...form, category: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20">
                <option>Mesleki Gelişim</option>
                <option>Kişisel Gelişim</option>
                <option>Yabancı Dil</option>
                <option>Teknoloji & Bilişim</option>
                <option>Sağlık Bilimleri</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Eğitim Formatı</label>
              <input type="text" value={form.location} onChange={e=>setForm({...form, location: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: Online (Zoom) veya Derslik A1" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Durum</label>
              <select value={form.status} onChange={e=>setForm({...form, status: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20">
                <option>Aktif</option>
                <option>Yayında</option>
                <option>Taslak</option>
                <option>Kapalı</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-5">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Başlama Tarihi</label>
              <input type="date" value={form.startDate} onChange={e=>setForm({...form, startDate: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Bitiş Tarihi</label>
              <input type="date" value={form.endDate} onChange={e=>setForm({...form, endDate: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Ders Saatleri</label>
              <input type="text" value={form.courseTime} onChange={e=>setForm({...form, courseTime: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="18:00 - 21:00" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Toplam Süre</label>
              <input type="text" value={form.duration} onChange={e=>setForm({...form, duration: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: 30 Saat" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Ücret (₺)</label>
              <input type="text" value={form.price} onChange={e=>setForm({...form, price: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: 2500 veya Ücretsiz" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Kontenjan</label>
              <input type="number" value={form.quota} onChange={e=>setForm({...form, quota: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: 25" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Son Başvuru</label>
              <input type="date" value={form.deadline} onChange={e=>setForm({...form, deadline: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Kısa Açıklama</label>
            <input type="text" value={form.shortDescription} onChange={e=>setForm({...form, shortDescription: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Önizleme kartında görünecek kısa metin" maxLength={150} />
          </div>

          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Eğitim İçeriği ve Detaylar</label>
            <textarea value={form.description} onChange={e=>setForm({...form, description: e.target.value})} rows={5} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-red-500/20 resize-none" placeholder="Eğitimin amacı, müfredatı ve diğer detaylar..."></textarea>
          </div>

          <div className="flex items-center gap-4 py-2 border-y border-gray-100">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.certificateAvailable} onChange={e=>setForm({...form, certificateAvailable: e.target.checked})} className="w-4 h-4 rounded text-red-600 focus:ring-red-500/20" />
              <span className="text-sm font-bold text-gray-700">Sertifika / Katılım Belgesi Verilecek</span>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2 border-t border-gray-100">
            <MediaUploader 
              label="Eğitim Görseli / Afiş" 
              image={form.image} 
              onImageChange={(val) => setForm({...form, image: val})} 
              aspect="16:9" 
            />
            <AttachmentUploader 
              label="Ek Dosya (PDF Müfredat)" 
              file={form.pdf} 
              onFileChange={(val) => setForm({...form, pdf: val})} 
            />
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button type="button" onClick={() => setIsEditing(false)} className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-600 hover:bg-gray-100 transition">İptal</button>
            <button type="submit" className="px-6 py-2.5 rounded-xl text-sm font-bold bg-red-600 text-white hover:bg-red-700 shadow-sm hover:shadow-md transition">Eğitimi Kaydet</button>
          </div>
        </form>
      </div>

      {/* RIGHT: LIVE PREVIEW */}
      <div className="w-full lg:w-[380px] shrink-0">
        <div className="sticky top-6">
          <h4 className="text-xs font-black text-gray-400 uppercase tracking-wider mb-3">Canlı Önizleme</h4>
          
          {/* Card Preview */}
          <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
            {/* Image Area */}
            <div className="h-40 bg-gray-100 relative group">
              {form.image ? (
                <img src={form.image} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
                  <BookOpen size={32} />
                  <span className="text-[10px] font-bold uppercase tracking-wider mt-2">Görsel Yok</span>
                </div>
              )}
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-md shadow-sm">
                <span className={`text-[10px] font-black uppercase tracking-wider ${(form.status === 'Aktif' || form.status === 'Yayında') ? 'text-emerald-600' : 'text-orange-600'}`}>
                  {form.status}
                </span>
              </div>
            </div>

            {/* Content Area */}
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider">{form.category || 'KATEGORİ'}</span>
                {form.price && form.price.toLowerCase() !== 'ücretsiz' && (
                  <span className="text-[12px] font-black text-emerald-600">{form.price} ₺</span>
                )}
                {form.price && form.price.toLowerCase() === 'ücretsiz' && (
                  <span className="text-[12px] font-black text-emerald-600">Ücretsiz</span>
                )}
              </div>
              
              <h3 className="text-[16px] font-black text-gray-900 leading-tight mb-2">
                {form.title || 'Eğitim Başlığı'}
              </h3>
              
              <p className="text-[13px] font-medium text-gray-500 mb-4 line-clamp-2">
                {form.shortDescription || form.description || 'Eğitim hakkında kısa bir açıklama veya özet bilgisi burada yer alacaktır.'}
              </p>

              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl mb-4 border border-gray-100">
                <div className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0 border border-gray-100">
                  <UserCheck size={18} className="text-gray-400"/>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">EĞİTMEN</p>
                  <p className="text-[13px] font-bold text-gray-900 leading-tight truncate w-48">{form.instructorTitle} {form.instructorName || 'Ad Soyad'}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-y-2 mb-4">
                <div className="flex items-center gap-1.5 text-gray-500">
                  <Calendar size={13} />
                  <span className="text-[11px] font-bold">{form.startDate ? form.startDate.split('-').reverse().join('.') : 'Belirtilmedi'}</span>
                </div>
                <div className="flex items-center gap-1.5 text-gray-500">
                  <Clock size={13} />
                  <span className="text-[11px] font-bold">{form.duration || 'Süre Belirtilmedi'}</span>
                </div>
              </div>
              
              {form.certificateAvailable && (
                <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-lg mb-4 w-fit">
                  <Award size={14} />
                  <span className="text-[11px] font-bold uppercase tracking-wider">Sertifikalı Program</span>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  Son: {form.deadline ? form.deadline.split('-').reverse().join('.') : '-'}
                </div>
                <button disabled className="text-[12px] font-bold bg-gray-900 text-white px-4 py-2 rounded-lg opacity-50 cursor-not-allowed">
                  Kayıt Ol
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <AdminCMSLayout>
      <div className="animate-fade-in">
        {isEditing ? formView : listView}
      </div>
    </AdminCMSLayout>
  );
}
