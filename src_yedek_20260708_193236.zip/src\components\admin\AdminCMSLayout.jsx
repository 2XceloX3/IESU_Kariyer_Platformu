import React from 'react';
import { Search } from 'lucide-react';

export function TopInfoCard({ title, count, icon, trend }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm flex items-center justify-between">
      <div>
        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">{title}</p>
        <p className="text-2xl font-black text-gray-900 flex items-center gap-2">
          {count}
          {trend && <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-md ${trend > 0 ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>{trend > 0 ? '+' : ''}{trend}</span>}
        </p>
      </div>
      <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
        {icon}
      </div>
    </div>
  );
}

export function SearchFilterBar({ searchQuery, setSearchQuery, placeholder = "Ara..." }) {
  return (
    <div className="relative w-full md:max-w-md">
      <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
      <input 
        type="text" 
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-white border border-gray-200 rounded-xl py-2 pl-10 pr-4 text-[14px] focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
      />
    </div>
  );
}

export function Badge({ children, type = 'default' }) {
  const colors = {
    success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    danger: 'bg-red-50 text-red-700 border-red-200',
    info: 'bg-blue-50 text-blue-700 border-blue-200',
    default: 'bg-gray-50 text-gray-700 border-gray-200'
  };
  return (
    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${colors[type] || colors.default}`}>
      {children}
    </span>
  );
}

export function PanelHeader({ badge = 'İESÜ Kariyer', title, sub, action }) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <span className="inline-block text-xs font-bold uppercase tracking-widest text-red-600 bg-red-50 border border-red-200 px-3 py-1 rounded-full mb-2">{badge}</span>
        <h1 className="text-3xl font-black text-gray-900 leading-tight">{title}</h1>
        {sub && <p className="text-gray-400 text-sm mt-1">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export default function AdminCMSLayout({ title, sub, isEditing, listView, formView, previewView, feedPreviewView, headerAction, children }) {
  return (
    <div className="animate-fade-in space-y-6">
      <PanelHeader title={title} sub={sub} action={headerAction} />
      
      {isEditing ? (
        <div className="flex flex-col lg:flex-row gap-6 items-start">
          {/* Form Alanı */}
          <div className="flex-1 w-full max-w-3xl bg-white border border-gray-100 shadow-sm rounded-2xl p-6">
            <h3 className="text-lg font-black text-gray-900 mb-6 border-b border-gray-100 pb-3">İçerik Düzenleyici</h3>
            {formView}
          </div>
          
          {/* Canlı Önizleme + Akış Önizleme */}
          <div className="w-full lg:w-[400px] shrink-0 lg:sticky lg:top-4 space-y-4">
            {/* Kart Önizleme */}
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Canlı Önizleme</h3>
            </div>
            <div className="bg-gray-50 rounded-2xl border border-gray-200 p-4 shadow-inner min-h-[300px] flex items-center justify-center relative overflow-hidden">
              <div className="w-full">
                 {previewView}
              </div>
            </div>

            {/* Akışta Nasıl Görünür? */}
            {feedPreviewView && (
              <div className="mt-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Akışta Görünüm</h3>
                </div>
                <div className="bg-[#F8F9FC] rounded-2xl border border-gray-200 p-3 shadow-inner relative overflow-hidden">
                  <div className="w-full">
                    {feedPreviewView}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {children ? children : (
            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-6">
              {listView}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
