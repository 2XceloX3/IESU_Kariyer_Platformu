import React from 'react';

export default function PanelHeader({ badge='İESÜ Kariyer', title, sub, action }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-100 text-red-700 rounded-full text-[10px] font-black uppercase tracking-widest mb-3">
          <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span>
          {badge}
        </div>
        <h2 className="text-2xl font-black text-gray-900 leading-tight">{title}</h2>
        {sub && <p className="text-sm text-gray-500 font-medium mt-1">{sub}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}
