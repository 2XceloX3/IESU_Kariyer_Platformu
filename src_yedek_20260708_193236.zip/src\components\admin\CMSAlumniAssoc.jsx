import React, { useState } from 'react';
import { Heart, Plus, Trash2, CheckCircle, Search, Users, Calendar, Activity, Eye, EyeOff } from 'lucide-react';
import PanelHeader from './PanelHeader';

export default function CMSAlumniAssoc({ posts = [], setPosts }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    title: '',
    content: '',
    contentType: 'Duyuru', // Duyuru, Etkinlik, Buluşma
    visibility: 'alumni', // public, alumni, students, academic
  });
  const [search, setSearch] = useState('');

  const assocPosts = (posts || []).filter(p => p.author?.id === 'mezun_dernegi');
  const filtered = assocPosts.filter(p => 
    p.title?.toLowerCase().includes(search.toLowerCase()) || 
    p.content?.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdd = (e) => {
    e.preventDefault();
    const newPost = {
      id: `AA-POST-${Date.now()}`,
      author: {
        id: 'mezun_dernegi',
        name: 'Mezun Derneği',
        avatar: 'https://ui-avatars.com/api/?name=Mezun+Dernegi&background=b91c1c&color=fff',
        title: 'Resmi Topluluk',
        type: 'admin'
      },
      ...form,
      date: new Date().toLocaleDateString('tr-TR'),
      likes: 0,
      comments: 0,
      status: 'Yayında',
      source: 'admin'
    };
    
    setPosts([newPost, ...(posts || [])]);
    setForm({ title: '', content: '', contentType: 'Duyuru', visibility: 'alumni' });
    setShowForm(false);
  };

  const deletePost = (id) => {
    setPosts((posts || []).filter(p => p.id !== id));
  };

  const toggleStatus = (id) => {
    setPosts((posts || []).map(p => {
      if (p.id === id) {
        return { ...p, status: p.status === 'Yayında' ? 'Arşiv' : 'Yayında' };
      }
      return p;
    }));
  };

  return (
    <div className="animate-fade-in space-y-6">
      <PanelHeader 
        title="Mezun Derneği (CMS)" 
        sub="Mezun derneği duyuru, etkinlik ve buluşma içeriklerini yönetin"
        action={
          <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl text-sm font-bold transition">
            <Plus size={16} /> Yeni İçerik Ekle
          </button>
        }
      />

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600"><Heart size={24}/></div>
          <div><p className="text-sm font-bold text-gray-500">Toplam İçerik</p><p className="text-2xl font-black text-gray-900">{assocPosts.length}</p></div>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center text-green-600"><CheckCircle size={24}/></div>
          <div><p className="text-sm font-bold text-gray-500">Yayında</p><p className="text-2xl font-black text-gray-900">{assocPosts.filter(p => p.status === 'Yayında').length}</p></div>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-orange-50 flex items-center justify-center text-orange-600"><Activity size={24}/></div>
          <div><p className="text-sm font-bold text-gray-500">Etkileşim (Beğeni)</p><p className="text-2xl font-black text-gray-900">{assocPosts.reduce((a, b) => a + (b.likes || 0), 0)}</p></div>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600"><Calendar size={24}/></div>
          <div><p className="text-sm font-bold text-gray-500">Etkinlikler</p><p className="text-2xl font-black text-gray-900">{assocPosts.filter(p => p.contentType === 'Etkinlik').length}</p></div>
        </div>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-2xl border-l-4 border-red-500 shadow-sm">
          <h3 className="text-lg font-black text-gray-900 mb-4">Yeni Dernek İçeriği</h3>
          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-gray-600 block mb-1">Başlık</label>
                <input type="text" required value={form.title} onChange={e => setForm({...form, title: e.target.value})} placeholder="Örn: 2026 Mezunlar Buluşması" className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-red-300 outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">İçerik Türü</label>
                  <select value={form.contentType} onChange={e => setForm({...form, contentType: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-red-300 outline-none">
                    <option value="Duyuru">Duyuru</option>
                    <option value="Etkinlik">Etkinlik</option>
                    <option value="Buluşma">Buluşma</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 block mb-1">Görünürlük</label>
                  <select value={form.visibility} onChange={e => setForm({...form, visibility: e.target.value})} className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-red-300 outline-none">
                    <option value="public">Herkes (Genel Akış)</option>
                    <option value="alumni">Sadece Mezunlar</option>
                    <option value="students">Öğrenciler ve Mezunlar</option>
                  </select>
                </div>
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1">İçerik Metni</label>
              <textarea required value={form.content} onChange={e => setForm({...form, content: e.target.value})} rows="4" placeholder="İçerik detaylarını buraya yazın..." className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-red-300 outline-none resize-none"></textarea>
            </div>
            <div className="flex gap-3">
              <button type="submit" className="bg-red-600 text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-red-700 transition">Yayınla</button>
              <button type="button" onClick={() => setShowForm(false)} className="bg-gray-100 text-gray-700 px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-gray-200 transition">İptal</button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-black text-gray-900">Dernek İçerikleri</h3>
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} type="text" placeholder="İçerik ara..." className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-red-300 w-64" />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="py-3 px-5 text-xs font-bold text-gray-500 uppercase tracking-wider">İçerik</th>
                <th className="py-3 px-5 text-xs font-bold text-gray-500 uppercase tracking-wider">Tür & Görünürlük</th>
                <th className="py-3 px-5 text-xs font-bold text-gray-500 uppercase tracking-wider">Etkileşim</th>
                <th className="py-3 px-5 text-xs font-bold text-gray-500 uppercase tracking-wider">Durum</th>
                <th className="py-3 px-5 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <tr><td colSpan="5" className="py-8 text-center text-gray-500 text-sm">İçerik bulunamadı.</td></tr>
              ) : filtered.map(post => (
                <tr key={post.id} className="hover:bg-gray-50/50 transition">
                  <td className="py-3 px-5">
                    <p className="font-bold text-gray-900 text-sm line-clamp-1">{post.title || 'Başlıksız'}</p>
                    <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{post.content}</p>
                    <p className="text-[10px] text-gray-400 mt-1">{post.date}</p>
                  </td>
                  <td className="py-3 px-5">
                    <div className="flex flex-col gap-1 items-start">
                      <span className="text-[11px] font-bold px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md border border-blue-100">{post.contentType}</span>
                      <span className="text-[10px] font-medium text-gray-500 flex items-center gap-1"><Users size={10}/> {post.visibility === 'public' ? 'Herkes' : post.visibility === 'alumni' ? 'Sadece Mezunlar' : 'Öğrenciler & Mezunlar'}</span>
                    </div>
                  </td>
                  <td className="py-3 px-5">
                    <p className="text-xs text-gray-600 font-medium">{post.likes || 0} Beğeni, {post.comments || 0} Yorum</p>
                  </td>
                  <td className="py-3 px-5">
                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border ${post.status === 'Yayında' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-gray-50 text-gray-600 border-gray-200'}`}>
                      {post.status}
                    </span>
                  </td>
                  <td className="py-3 px-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => toggleStatus(post.id)} className={`p-1.5 rounded-lg transition ${post.status === 'Yayında' ? 'text-amber-500 hover:bg-amber-50' : 'text-emerald-500 hover:bg-emerald-50'}`} title={post.status === 'Yayında' ? 'Yayından Kaldır' : 'Yayınla'}>
                        {post.status === 'Yayında' ? <EyeOff size={16}/> : <Eye size={16}/>}
                      </button>
                      <button onClick={() => deletePost(post.id)} className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition" title="Sil">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
