import React, { useState } from 'react';
import { ArrowLeft, Download, CheckCircle2, AlertCircle, X, Search, FileDown } from 'lucide-react';

// Tiny CSV Parser handling quotes and newlines
function parseCSV(text) {
  let p = '', row = [''], ret = [row], i = 0, r = 0, s = !0, l;
  for (l of text) {
    if ('"' === l) {
      if (s && l === p) row[i] += l;
      s = !s;
    } else if (',' === l && s) l = row[++i] = '';
    else if ('\n' === l && s) {
      if ('\r' === p) row[i] = row[i].slice(0, -1);
      row = ret[++r] = [l = '']; i = 0;
    } else row[i] += l;
    p = l;
  }
  // remove last empty row if exists
  if (ret[ret.length-1].length === 1 && ret[ret.length-1][0] === '') ret.pop();
  return ret;
}

export default function CompanyImport({ onClose, companies, setCompanies }) {
  const [sheetUrl, setSheetUrl] = useState('https://docs.google.com/spreadsheets/d/1palGm9P0LEXOgED-jW_o-_zQbxOc1EJzYthANFLejF8/export?format=csv');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [previewData, setPreviewData] = useState([]);
  const [selectedIndices, setSelectedIndices] = useState(new Set());

  const handleFetch = async () => {
    setLoading(true);
    setError('');
    setPreviewData([]);
    setSelectedIndices(new Set());

    try {
      const response = await fetch(sheetUrl);
      if (!response.ok) throw new Error('Veri çekilemedi. Bağlantıyı kontrol edin.');
      
      const csvText = await response.text();
      const parsed = parseCSV(csvText);

      if (parsed.length < 2) throw new Error('Tabloda veri bulunamadı.');

      const headers = parsed[0];
      const nameIdx = headers.findIndex(h => h.includes('İşletme Adı'));
      const emailIdx = headers.findIndex(h => h.includes('E-posta'));
      const contactIdx = headers.findIndex(h => h.includes('Yetkili Kişi'));
      const phoneIdx = headers.findIndex(h => h.includes('Telefon Numarası'));

      if (nameIdx === -1 || emailIdx === -1) {
        throw new Error('CSV dosyasında "İşletme Adı" veya "E-posta" sütunları bulunamadı.');
      }

      const rows = parsed.slice(1).map(row => {
        const name = row[nameIdx] || '';
        const email = row[emailIdx] || '';
        const authorizedPerson = contactIdx !== -1 ? row[contactIdx] : '';
        const phone = phoneIdx !== -1 ? row[phoneIdx] : '';

        // Extract Google Drive ID from the row to use as logo
        let logo = '';
        for (const col of row) {
          if (col && typeof col === 'string' && col.includes('drive.google.com/file/d/')) {
            const match = col.match(/\/d\/([a-zA-Z0-9_-]+)/);
            if (match && match[1]) {
              // Convert to direct download/view link
              logo = `https://drive.google.com/uc?id=${match[1]}`;
              break;
            }
          }
        }

        // Check duplicates
        const isDuplicate = companies.some(c => 
          c.name.toLowerCase() === name.toLowerCase() || 
          c.email.toLowerCase() === email.toLowerCase()
        );

        return { name, email, authorizedPerson, phone, logo, isDuplicate };
      }).filter(r => r.name.trim() !== '');

      setPreviewData(rows);
      
      // Select non-duplicates by default
      const initialSelection = new Set();
      rows.forEach((r, idx) => {
        if (!r.isDuplicate) initialSelection.add(idx);
      });
      setSelectedIndices(initialSelection);

    } catch (err) {
      setError(err.message || 'Bilinmeyen bir hata oluştu.');
    } finally {
      setLoading(false);
    }
  };

  const toggleSelection = (idx) => {
    const newSel = new Set(selectedIndices);
    if (newSel.has(idx)) newSel.delete(idx);
    else newSel.add(idx);
    setSelectedIndices(newSel);
  };

  const handleImport = () => {
    const toAdd = previewData
      .filter((_, idx) => selectedIndices.has(idx))
      .map(row => ({
        id: 'CMP-IMP-' + Date.now() + Math.floor(Math.random() * 1000),
        name: row.name,
        email: row.email,
        authorizedPerson: row.authorizedPerson,
        phone: row.phone,
        logo: row.logo,
        sector: 'Bilinmiyor',
        status: 'Onaylı',
        createdAt: new Date().toISOString(),
        activeJobs: 0,
        source: 'imported'
      }));

    if (toAdd.length === 0) return;

    setCompanies([...toAdd, ...companies]);
    onClose();
  };

  return (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden flex flex-col h-[80vh]">
      <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="p-2 hover:bg-white rounded-xl transition text-gray-500 hover:text-gray-900 border border-transparent hover:border-gray-200">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-xl font-black text-gray-900 flex items-center gap-2"><FileDown className="text-iesu-red" size={24} /> Google Sheets'ten Firma İçe Aktar</h2>
            <p className="text-sm font-medium text-gray-500">Etkinlik başvuru formundan gelen Google Sheets verilerini çekin ve logoları eşleştirin.</p>
          </div>
        </div>
      </div>

      <div className="p-6 border-b border-gray-100 flex gap-4">
        <input 
          type="text" 
          value={sheetUrl}
          onChange={(e) => setSheetUrl(e.target.value)}
          placeholder="Google Sheets CSV Export Linki"
          className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all"
        />
        <button 
          onClick={handleFetch}
          disabled={loading || !sheetUrl.trim()}
          className="bg-gray-900 text-white px-6 py-3 rounded-xl font-bold text-sm hover:bg-gray-800 disabled:opacity-50 transition-colors flex items-center gap-2"
        >
          {loading ? 'Yükleniyor...' : <><Search size={18} /> Verileri Getir</>}
        </button>
      </div>

      {error && (
        <div className="mx-6 mt-6 p-4 bg-red-50 text-red-700 rounded-xl font-medium text-sm flex items-center gap-2 border border-red-100">
          <AlertCircle size={18} /> {error}
        </div>
      )}

      <div className="flex-1 overflow-auto p-6 bg-gray-50/30">
        {previewData.length > 0 ? (
          <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="p-4 w-12 text-center">
                    <input 
                      type="checkbox" 
                      className="rounded text-iesu-red focus:ring-iesu-red"
                      checked={selectedIndices.size === previewData.length}
                      onChange={(e) => {
                        if (e.target.checked) setSelectedIndices(new Set(previewData.map((_, i) => i)));
                        else setSelectedIndices(new Set());
                      }}
                    />
                  </th>
                  <th className="p-4">Logo Durumu</th>
                  <th className="p-4">Firma Adı</th>
                  <th className="p-4">Yetkili Kişi</th>
                  <th className="p-4">E-posta</th>
                  <th className="p-4">Sistemde Durumu</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {previewData.map((row, idx) => (
                  <tr key={idx} className={`hover:bg-gray-50 transition-colors ${row.isDuplicate ? 'bg-orange-50/30' : ''}`}>
                    <td className="p-4 text-center">
                      <input 
                        type="checkbox" 
                        checked={selectedIndices.has(idx)}
                        onChange={() => toggleSelection(idx)}
                        className="rounded text-iesu-red focus:ring-iesu-red"
                      />
                    </td>
                    <td className="p-4">
                      {row.logo ? (
                        <span className="inline-flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md text-[10px] font-bold"><CheckCircle2 size={12}/> Logo Bulundu</span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-gray-400 bg-gray-100 px-2 py-1 rounded-md text-[10px] font-bold"><X size={12}/> Logo Yok</span>
                      )}
                    </td>
                    <td className="p-4 font-bold text-gray-900">{row.name}</td>
                    <td className="p-4 text-gray-600">{row.authorizedPerson}</td>
                    <td className="p-4 text-gray-600">{row.email}</td>
                    <td className="p-4">
                      {row.isDuplicate ? (
                        <span className="inline-flex items-center gap-1 text-orange-600 font-bold text-xs"><AlertCircle size={14}/> Mükerrer (Varolan Firma)</span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-blue-600 font-bold text-xs"><CheckCircle2 size={14}/> Yeni Eklenecek</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          !loading && !error && (
            <div className="h-full flex flex-col items-center justify-center text-gray-400">
              <FileDown size={48} className="mb-4 opacity-20" />
              <p className="font-medium">İçe aktarmak için Google Sheets bağlantısını girip verileri getirin.</p>
            </div>
          )
        )}
      </div>

      <div className="p-6 border-t border-gray-100 bg-white flex justify-end gap-3">
        <button onClick={onClose} className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-600 hover:bg-gray-100 transition-colors">İptal</button>
        <button 
          onClick={handleImport}
          disabled={selectedIndices.size === 0}
          className="bg-iesu-red text-white px-8 py-2.5 rounded-xl text-sm font-bold hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center gap-2 shadow-sm"
        >
          <CheckCircle2 size={18} /> Seçili {selectedIndices.size} Firmayı İçeri Aktar
        </button>
      </div>
    </div>
  );
}
