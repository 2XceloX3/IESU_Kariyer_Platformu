import React, { useState } from 'react';
import AdminCMSLayout from './AdminCMSLayout';
import MediaUploader from './MediaUploader';
import AttachmentUploader from './AttachmentUploader';
import { Calendar, CheckCircle2, MapPin, Edit, Trash2, Plus, Search, Filter, Image as ImageIcon } from 'lucide-react';

export default function CMSEvents({ events = [], setEvents }) {
  const [isEditing, setIsEditing] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const [form, setForm] = useState({
    title: '',
    date: '',
    time: '',
    location: '',
    description: '',
    imageUrl: '',
    attachmentData: null,
    attachmentName: '',
    registrationLink: '',
    status: 'Yayında'
  });

  const handleAddNew = () => {
    setForm({
      title: '',
      date: '',
      time: '',
      location: '',
      description: '',
      imageUrl: '',
      attachmentData: null,
      attachmentName: '',
      registrationLink: '',
      status: 'Yayında'
    });
    setCurrentId(null);
    setIsEditing(true);
  };

  const handleEdit = (ev) => {
    setForm({ 
      ...ev,
      time: ev.time || ''
    });
    setCurrentId(ev.id);
    setIsEditing(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("Bu etkinliği silmek istediğinize emin misiniz?")) {
      setEvents((events || []).filter(e => e.id !== id));
    }
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!form.title || !form.date) return alert("Başlık ve tarih zorunludur.");

    if (currentId) {
      setEvents((events || []).map(ev => ev.id === currentId ? { ...ev, ...form, updatedAt: new Date().toISOString() } : ev));
    } else {
      setEvents([{ ...form, id: 'NE-E' + Date.now(), type: 'Etkinlik', createdAt: new Date().toISOString() }, ...events]);
    }
    setIsEditing(false);
  };

  const filtered = (events || []).filter(e => {
    const matchQ = (e.title||'').toLowerCase().includes(searchQuery.toLowerCase());
    const matchS = statusFilter === 'all' || (e.status||'').toLowerCase() === statusFilter.toLowerCase();
    return matchQ && matchS;
  });

  const activeCount = (events || []).filter(e => e.status === 'Yayında').length;
  const draftCount = (events || []).filter(e => e.status === 'Taslak').length;

  const listView = (
    <div className="space-y-6">
      {/* HEADER & STATS */}
      <div>
        <div className="flex justify-between items-end mb-4">
          <div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">Etkinlik Yönetimi</h2>
            <p className="text-sm font-medium text-gray-500 mt-1">Sistemdeki kariyer fuarları, seminerler ve etkinlikleri yönetin.</p>
          </div>
          <button onClick={handleAddNew} className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 shadow-sm transition-all hover:shadow-md">
            <Plus size={18} /> Yeni Etkinlik Ekle
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center"><Calendar size={24}/></div>
            <div><p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Toplam Etkinlik</p><p className="text-2xl font-black text-gray-900">{(events || []).length}</p></div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center"><CheckCircle2 size={24}/></div>
            <div><p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Yayında</p><p className="text-2xl font-black text-gray-900">{activeCount}</p></div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center"><Edit size={24}/></div>
            <div><p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Taslak Bekleyen</p><p className="text-2xl font-black text-gray-900">{draftCount}</p></div>
          </div>
        </div>
      </div>

      {/* FILTERS */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input 
            type="text" placeholder="Etkinlik ara..." 
            className="w-full pl-10 pr-4 py-2 bg-gray-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-red-500/20 transition-all"
            value={searchQuery} onChange={e=>setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} className="bg-gray-50 border-none text-sm font-medium rounded-xl px-4 py-2 focus:ring-2 focus:ring-red-500/20 outline-none cursor-pointer">
            <option value="all">Tüm Durumlar</option>
            <option value="yayında">Yayında</option>
            <option value="taslak">Taslak</option>
          </select>
          <button className="p-2 bg-gray-50 text-gray-600 rounded-xl hover:bg-gray-100 transition"><Filter size={18}/></button>
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 bg-gray-50 text-gray-400 rounded-full flex items-center justify-center mb-4"><Calendar size={32}/></div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">Kayıt Bulunamadı</h3>
            <p className="text-sm text-gray-500">Arama kriterlerine uygun etkinlik bulunmuyor.</p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-100">
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Etkinlik</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Tarih & Saat</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Konum</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider">Durum</th>
                <th className="py-3 px-5 text-[11px] font-bold text-gray-400 uppercase tracking-wider text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map(e => (
                <tr key={e.id} className="hover:bg-gray-50/50 transition group">
                  <td className="py-3 px-5">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-gray-100 overflow-hidden shrink-0">
                        {e.imageUrl ? <img src={e.imageUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Calendar size={20} className="text-gray-400"/></div>}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900 truncate max-w-[200px]">{e.title}</p>
                        <p className="text-[11px] font-medium text-gray-500 mt-0.5 truncate max-w-[200px]">{e.description}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-5">
                    <p className="text-sm font-bold text-gray-700">{e.date || 'Belirtilmedi'}</p>
                    <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mt-0.5">{e.time || '-'}</p>
                  </td>
                  <td className="py-3 px-5">
                    <p className="text-xs font-bold text-gray-700 flex items-center gap-1"><MapPin size={12}/> {e.location || 'Belirtilmedi'}</p>
                  </td>
                  <td className="py-3 px-5">
                    <span className={`inline-flex px-2.5 py-1 rounded-md text-[11px] font-black uppercase tracking-wider
                      ${(e.status === 'Yayında') ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'}`}>
                      {e.status}
                    </span>
                  </td>
                  <td className="py-3 px-5 text-right">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition">
                      <button onClick={() => handleEdit(e)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"><Edit size={16}/></button>
                      <button onClick={() => handleDelete(e.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"><Trash2 size={16}/></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );

  const actualFormView = (
    <div className="flex-1">
      <div className="flex-1 bg-white border border-gray-100 rounded-2xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
          <h3 className="text-lg font-black text-gray-900">{currentId ? 'Etkinliği Düzenle' : 'Yeni Etkinlik'}</h3>
          <button type="button" onClick={() => setIsEditing(false)} className="text-sm font-bold text-gray-500 hover:text-gray-900 transition">İptal</button>
        </div>

        <form onSubmit={handleSave} className="space-y-5">
          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Etkinlik Başlığı <span className="text-red-500">*</span></label>
            <input type="text" value={form.title} onChange={e=>setForm({...form, title: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Etkinlik adını girin..." required />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Tarih <span className="text-red-500">*</span></label>
              <input type="text" value={form.date} onChange={e=>setForm({...form, date: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: 20 Eylül 2026" required />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Saat</label>
              <input type="text" value={form.time} onChange={e=>setForm({...form, time: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: 14:00" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Konum</label>
              <input type="text" value={form.location} onChange={e=>setForm({...form, location: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="Örn: Konferans Salonu 1" />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-600 block mb-1.5">Durum</label>
              <select value={form.status} onChange={e=>setForm({...form, status: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20">
                <option>Yayında</option>
                <option>Taslak</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Kayıt / Başvuru Linki (Varsa)</label>
            <input type="url" value={form.registrationLink} onChange={e=>setForm({...form, registrationLink: e.target.value})} className="w-full bg-gray-50 border-none rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-red-500/20" placeholder="https://" />
          </div>

          <div>
            <label className="text-xs font-bold text-gray-600 block mb-1.5">Açıklama</label>
            <textarea value={form.description} onChange={e=>setForm({...form, description: e.target.value})} rows={5} className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-red-500/20 resize-none" placeholder="Etkinlik detayları..."></textarea>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-4 border-t border-gray-100">
            <MediaUploader 
              label="Etkinlik Afişi / Görsel" 
              image={form.imageUrl} 
              onImageChange={(val) => setForm({...form, imageUrl: val})} 
              aspect="16:9" 
            />
            <AttachmentUploader 
              label="Ek Dosya (PDF vs.)" 
              file={form.attachmentData} 
              onFileChange={(val) => setForm({...form, attachmentData: val, attachmentName: val ? 'Ek_Dosya' : ''})} 
            />
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
            <button type="button" onClick={() => setIsEditing(false)} className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-600 hover:bg-gray-100 transition">İptal</button>
            <button type="submit" className="px-6 py-2.5 rounded-xl text-sm font-bold bg-red-600 text-white hover:bg-red-700 shadow-sm hover:shadow-md transition">Etkinliği Kaydet</button>
          </div>
        </form>
      </div>
    </div>
  );

  const previewView = (
    <div className="bg-white rounded-3xl border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] overflow-hidden">
      <div className="h-48 bg-gray-100 relative group">
        {form.imageUrl ? (
          <img src={form.imageUrl} alt="Preview" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
            <ImageIcon size={32} />
            <span className="text-[10px] font-bold uppercase tracking-wider mt-2">Görsel Yok</span>
          </div>
        )}
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-md shadow-sm">
          <span className={`text-[10px] font-black uppercase tracking-wider ${(form.status === 'Yayında') ? 'text-emerald-600' : 'text-orange-600'}`}>
            {form.status}
          </span>
        </div>
      </div>

      <div className="p-5">
        <span className="bg-red-50 text-red-600 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider inline-block mb-2">ETKİNLİK</span>
        
        <h3 className="text-[18px] font-black text-gray-900 leading-tight mb-3">
          {form.title || 'Etkinlik Başlığı'}
        </h3>
        
        <div className="flex flex-col gap-2 mb-4">
          <div className="flex items-center gap-2 text-[12px] font-bold text-gray-600">
            <Calendar size={14} className="text-red-500" />
            <span>{form.date || 'Tarih Belirtilmedi'} {form.time ? `- ${form.time}` : ''}</span>
          </div>
          <div className="flex items-center gap-2 text-[12px] font-bold text-gray-600">
            <MapPin size={14} className="text-red-500" />
            <span>{form.location || 'Konum Belirtilmedi'}</span>
          </div>
        </div>

        <p className="text-[13px] font-medium text-gray-500 mb-5 line-clamp-3">
          {form.description || 'Etkinlik hakkında detaylı bilgi burada görünecektir.'}
        </p>

        <button disabled className="w-full py-2.5 bg-gray-900 text-white rounded-xl text-[13px] font-bold opacity-50 cursor-not-allowed">
          Kayıt Ol / Detaylar
        </button>
      </div>
    </div>
  );

  const feedPreviewView = form.title ? (
    <div className="bg-white/80 backdrop-blur-xl rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-9 h-9 rounded-full bg-red-100 flex items-center justify-center">
            <Calendar size={16} className="text-red-600" />
          </div>
          <div>
            <p className="text-[13px] font-bold text-gray-900 flex items-center gap-1">Kariyer Geliştirme Ofisi <CheckCircle2 size={12} className="text-emerald-500" /></p>
            <p className="text-[10px] text-gray-400">Az önce • Etkinlik Paylaşımı</p>
          </div>
        </div>
        {form.imageUrl && (
          <div className="rounded-xl overflow-hidden mb-3 h-28">
            <img src={form.imageUrl} alt="" className="w-full h-full object-cover" />
          </div>
        )}
        <p className="text-[12px] font-bold text-gray-800 mb-1">{form.title}</p>
        <p className="text-[11px] text-gray-500 line-clamp-2">{form.description || ''}</p>
        <div className="flex items-center gap-3 mt-2 text-[10px] text-gray-400">
          <span>📅 {form.date || '...'}</span>
          <span>📍 {form.location || '...'}</span>
        </div>
      </div>
    </div>
  ) : null;

  return (
    <AdminCMSLayout
      title="Etkinlikler"
      sub="Sistemdeki yaklaşan etkinlikleri yönetin"
      isEditing={isEditing}
      listView={listView}
      formView={actualFormView}
      previewView={previewView}
      feedPreviewView={feedPreviewView}
    />
  );
}
