import React, { useState, useEffect, useRef } from 'react';
import { Send, Search, UserCircle2, CheckCircle2, ChevronLeft, MessageSquare } from 'lucide-react';

export default function MessagingInterface({ messages = [], setMessages, currentUser, userRole, contacts = [], setView, setSelectedUserId }) {
  // messages format: { id, senderId, senderName, senderAvatar, receiverId, receiverName, content, timestamp, read }
  
  const [activeContactId, setActiveContactId] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef(null);

  // Scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeContactId]);

  // Extract unique contacts from messages and merge with available contacts
  const getConversations = () => {
    const convos = new Map();
    
    // Add existing contacts from directory (if provided)
    contacts.forEach(c => {
      convos.set(c.id, {
        id: c.id,
        name: c.name,
        avatar: c.avatar || '',
        role: c.role || 'Kullanıcı',
        lastMessage: null,
        unreadCount: 0,
        timestamp: 0
      });
    });

    // Process messages to find recent chats
    messages.forEach(msg => {
      const isSender = msg.senderId === currentUser?.id;
      const isReceiver = msg.receiverId === currentUser?.id;
      
      if (!isSender && !isReceiver) return; // Not our message

      const otherId = isSender ? msg.receiverId : msg.senderId;
      
      const realContact = contacts.find(c => c.id === otherId);
      if (!realContact) return; // Skip orphan messages entirely

      const otherName = realContact.name;
      const otherAvatar = realContact.avatar || realContact.logo || '';
      const otherRole = realContact.department ? 'Öğrenci' : realContact.sector ? 'Firma' : realContact.gradYear ? 'Mezun' : 'Akademik';

      const existing = convos.get(otherId) || {
        id: otherId,
        name: otherName,
        avatar: otherAvatar,
        role: otherRole,
        unreadCount: 0
      };

      if (!existing.timestamp || msg.timestamp > existing.timestamp) {
        existing.lastMessage = msg?.content;
        existing.timestamp = msg.timestamp;
      }

      if (isReceiver && !msg?.read) {
        existing.unreadCount += 1;
      }

      convos.set(otherId, existing);
    });

    return Array.from(convos.values())
      .filter(c => c.lastMessage) // ONLY show contacts with message history
      .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  };

  const conversations = getConversations().filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeContact = conversations.find(c => c.id === activeContactId) || null;

  const currentChatMessages = (messages || [])
    .filter(msg => 
      (msg.senderId === currentUser?.id && msg.receiverId === activeContactId) ||
      (msg.receiverId === currentUser?.id && msg.senderId === activeContactId)
    )
    .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

  // Mark as read when opening a chat
  useEffect(() => {
    if (activeContactId) {
      const unreadMessages = currentChatMessages.filter(m => m.receiverId === currentUser?.id && !m.read);
      if (unreadMessages.length > 0) {
        const updatedMessages = (messages || []).map(m => 
          (m.receiverId === currentUser?.id && m.senderId === activeContactId) ? { ...m, read: true } : m
        );
        setMessages(updatedMessages);
      }
    }
  }, [activeContactId, messages, currentUser?.id]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeContactId) return;

    const newMsg = {
      id: 'MSG-' + Date.now(),
      senderId: currentUser?.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      receiverId: activeContact?.id,
      receiverName: activeContact?.name,
      receiverAvatar: activeContact?.avatar,
      content: newMessage.trim(),
      timestamp: Date.now(),
      read: false
    };

    setMessages([...messages, newMsg]);
    setNewMessage('');
  };

  const formatTime = (ts) => {
    if (!ts) return '';
    const date = new Date(ts);
    return date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-[1000px] mx-auto px-4 lg:px-8 h-16 flex items-center">
          <button onClick={() => {
            if (typeof setView === 'function') {
              if (!userRole) { setView(userRole === 'admin' ? 'admin' : userRole === 'employer' ? 'company' : userRole || 'landing'); }
              else if (userRole === 'employer') { setView('company'); }
              else { setView(userRole); }
            }
          }} className="flex items-center gap-2 text-gray-600 hover:text-iesu-red font-bold transition-colors">
            <ChevronLeft size={20} /> Geri Dön
          </button>
        </div>
      </nav>
      <main className="max-w-[1000px] mx-auto px-4 lg:px-8 pt-8">
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 overflow-hidden flex h-[700px]">
      
      {/* LEFT PANEL: Conversations List */}
      <div className={`w-full md:w-80 border-r border-gray-100 flex flex-col bg-gray-50/30 ${activeContactId ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-4 border-b border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-black text-gray-900">Mesajlar</h2>
            <button onClick={() => document.getElementById('chat-search')?.focus()} className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shadow-sm hover:scale-105 transition-transform" title="Yeni Mesaj">
              <span className="text-xl font-light mb-0.5">+</span>
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input 
              id="chat-search"
              type="text" 
              placeholder="Mesajlarda veya kişilerde ara..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-red-400 focus:ring-1 focus:ring-red-400 transition" 
            />
          </div>
        </div>

<div className="flex-1 overflow-y-auto">
          {(conversations || []).length > 0 ? (
            conversations.map(convo => (
              <div 
                key={convo.id}
                onClick={() => setActiveContactId(convo.id)}
                className={`flex items-center gap-3 p-4 cursor-pointer border-b border-gray-50 transition-colors ${activeContactId === convo.id ? 'bg-red-50/50' : 'hover:bg-gray-50'}`}
              >
                <div 
                  className="relative shrink-0 cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (setSelectedUserId) {
                      setSelectedUserId(convo.id);
                      setView('user_profile');
                    }
                  }}
                >
                  <img 
                    src={convo.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(convo.name)}&background=132A49&color=fff`} 
                    alt={convo.name}
                    className="w-12 h-12 rounded-full object-cover border border-gray-100 hover:border-red-300 transition-colors" 
                  />
                  {convo.unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 border-2 border-white rounded-full flex items-center justify-center text-[9px] font-bold text-white">
                      {convo.unreadCount}
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-0.5">
                    <h4 
                      className="text-sm font-bold text-gray-900 truncate hover:text-red-600 transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (setSelectedUserId) {
                          setSelectedUserId(convo.id);
                          setView('user_profile');
                        }
                      }}
                    >
                      {convo.name}
                    </h4>
                    {convo.lastMessage && (
                      <span className="text-[10px] font-medium text-gray-400 shrink-0 ml-2">
                        {new Date(convo.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <p className={`text-xs truncate ${convo.unreadCount > 0 ? 'font-bold text-gray-900' : 'font-medium text-gray-500'}`}>
                      {convo.lastMessage ? ((convo?.lastMessage || '').startsWith('Sen:') ? convo.lastMessage : convo.lastMessage) : <span className="italic">Mesajlaşmaya başlayın</span>}
                    </p>
                    <span className="text-[9px] font-bold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-2 shrink-0">{convo.role}</span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <MessageSquare size={32} className="text-gray-300 mb-3" />
              <p className="text-gray-500 font-medium text-sm">Henüz mesaj bulunmuyor.</p>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT PANEL: Active Chat */}
      <div className={`flex-1 flex flex-col bg-white ${!activeContactId ? 'hidden md:flex' : 'flex'}`}>
        {activeContact ? (
          <>
            {/* Chat Header */}
            <div className="h-16 border-b border-gray-100 flex items-center px-4 md:px-6 justify-between bg-white shrink-0 shadow-sm z-10">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setActiveContactId(null)} 
                  className="md:hidden p-2 -ml-2 text-gray-500 hover:text-gray-900 rounded-lg hover:bg-gray-50 transition"
                >
                  <ChevronLeft size={20} />
                </button>
                <img 
                  src={activeContact?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(activeContact?.name)}&background=132A49&color=fff`} 
                  alt={activeContact?.name} 
                  className="w-10 h-10 rounded-full object-cover border border-gray-200 cursor-pointer hover:border-red-300"
                  onClick={() => {
                    if (setSelectedUserId) {
                      setSelectedUserId(activeContact?.id);
                      setView('user_profile');
                    }
                  }}
                />
                <div 
                  className="cursor-pointer hover:text-red-600"
                  onClick={() => {
                    if (setSelectedUserId) {
                      setSelectedUserId(activeContact?.id);
                      setView('user_profile');
                    }
                  }}
                >
                  <h3 className="font-black text-gray-900 text-sm leading-tight transition">
                    {activeContact?.name}
                  </h3>
                  <p className="text-xs text-gray-500 font-medium">{activeContact?.role}</p>
                </div>
              </div>
              
              {/* Profile Link Button */}
              {setSelectedUserId && setView && (
                <button 
                  onClick={() => {
                    setSelectedUserId(activeContact?.id);
                    setView('user_profile');
                  }}
                  className="hidden md:flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                >
                  <UserCircle2 size={16} /> Profili Görüntüle
                </button>
              )}
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-gray-50/50">
              {(currentChatMessages || []).length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-2">
                  <MessageSquare size={32} className="text-gray-300" />
                  <p className="text-sm">Mesajlaşmaya başlayın...</p>
                </div>
              ) : (
                (currentChatMessages || []).map((msg, idx) => {
                  const isMine = msg.senderId === currentUser?.id;
                  return (
                    <div key={msg.id || idx} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${
                        isMine 
                          ? 'bg-red-600 text-white rounded-br-none shadow-md shadow-red-600/10' 
                          : 'bg-white text-gray-800 border border-gray-100 rounded-bl-none shadow-sm'
                      }`}>
                        <p className="text-[13px] leading-relaxed whitespace-pre-wrap break-words">{msg?.content}</p>
                        <div className={`flex items-center justify-end gap-1 mt-1 ${isMine ? 'text-red-200' : 'text-gray-400'}`}>
                          <span className="text-[10px]">{formatTime(msg.timestamp)}</span>
                          {isMine && <CheckCircle2 size={12} className={msg?.read ? 'text-white' : 'opacity-50'} />}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat Input */}
            <div className="p-4 bg-white border-t border-gray-100">
              <form onSubmit={handleSend} className="flex gap-2 relative items-end">
                <textarea 
                  rows={Math.min(Math.max((newMessage || '').split('\n').length, 1), 4)}
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend(e);
                    }
                  }}
                  placeholder="Bir mesaj yazın..." 
                  className="w-full bg-gray-50 border border-gray-200 rounded-2xl pl-4 pr-12 py-3 text-[13px] focus:outline-none focus:border-red-400 focus:bg-white focus:ring-2 focus:ring-red-100 transition resize-none"
                />
                <button 
                  type="submit"
                  disabled={!newMessage.trim()}
                  className="absolute right-2 bottom-2 p-2 bg-red-600 text-white rounded-xl hover:bg-red-700 disabled:opacity-50 disabled:hover:bg-red-600 transition shadow-sm"
                >
                  <Send size={16} />
                </button>
              </form>
              <p className="text-[10px] text-gray-400 text-center mt-2">
                Mesaj göndermek için Enter'a, yeni satır için Shift+Enter'a basın.
              </p>
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center px-4 bg-gray-50/50">
            <div className="w-20 h-20 bg-white rounded-full shadow-sm border border-gray-100 flex items-center justify-center mb-4 text-red-600">
              <Send size={32} className="ml-1" />
            </div>
            <h3 className="text-xl font-black text-gray-900 mb-2">Mesajlarınız</h3>
            <p className="text-sm text-gray-500 max-w-sm">
              Sohbete başlamak için sol taraftan bir kişi seçin veya yeni bir konuşma başlatın.
            </p>
          </div>
        )}
      </div>
    </div>
      </main>
    </div>
  );
}

